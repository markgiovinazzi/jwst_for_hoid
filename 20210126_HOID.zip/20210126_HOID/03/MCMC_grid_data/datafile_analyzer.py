import numpy as np
import matplotlib.pyplot as plt

def do_stuff(filename, filename2):

     data = open(filename, 'r')
     lines = data.readlines()
     lines = lines[1:]
     dof = []
     chi2 = []
     sigma_as = []
     a_trues = []
     a_recs = []
     arcs = np.arange(2, 21) / 2.
     for line in lines:

         dof.append(2 * float(line.split()[3]) - 6)
         chi2.append(float(line.split()[13]))
         sigma_as.append(float(line.split()[4]))
         a_trues.append(float(line.split()[7]))
         a_recs.append(float(line.split()[14]))
     dof = np.array(dof)
     chi2 = np.array(chi2)
     sigma_as = np.array(sigma_as)
     a_trues = np.array(a_trues)
     a_recs = np.array(a_recs)

     meds = []
     print(len(sigma_as))
     for j in range(19):

         meds.append(np.median(sigma_as[j::19]))
     #for i in range(9):
     #    print(sigma_as[i:i+19])
     #    plt.plot(arcs,sigma_as[19*i:19*i+19] , color = 'black')
         
     data = open(filename2, 'r')
     lines = data.readlines()
     lines = lines[1:]
     sigma_as = []
     
     for line in lines:

         sigma_as.append(float(line.split()[4]))
    
     sigma_as = np.array(sigma_as)
     print(len(meds))
     meds2 = []
     for j in range(19):
         meds2.append(np.median(sigma_as[j::19]))
     print(len(meds2))
     plt.plot(arcs, meds, color = 'blue', label = 'New')
     plt.plot(arcs, meds2, color = 'black', label = 'Old')
     plt.legend()
     plt.xlabel('arc length [mo]')
     plt.ylabel(r'$\frac{\sigma_a}{a}$')
     plt.semilogy()
     plt.semilogx()
     plt.ylim(8e-7, 1.5)
     plt.show()
     
do_stuff('perihelion_data.txt', '5s.txt')
