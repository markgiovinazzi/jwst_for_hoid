#!/bin/bash

declare -a dirs=("first_JWST" "second_JWST" "first_noJWST" "second_noJWST")

for dir in "${dirs[@]}"; do
    cd $dir
    python3 "analysis.py" &
    cd ".."
done

