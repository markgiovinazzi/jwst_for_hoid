import matplotlib.pyplot as plt
import numpy as np
import pickle
#from hpd_calc

bins = np.linspace(0, 1000, 1000)

a_trues = pickle.load(open('pickles/a_recs_true.p', 'rb'))

for random_realization in range(25):

    a_recs = pickle.load(open('pickles/a_recs_' + str(random_realization) + '.p', 'rb'))
    plt.hist(a_recs, histtype = 'step', bins = bins, alpha = 0.25, color = 'blue')

plt.hist(a_trues, histtype = 'step', bins = bins, lw = 3, color = 'black')
plt.axvline(x=86.7363909915201, label = 'True')
plt.show()
