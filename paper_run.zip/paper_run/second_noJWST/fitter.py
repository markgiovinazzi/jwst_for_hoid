import numpy as np, matplotlib.pyplot as plt
from astroquery.jplhorizons import Horizons
from unit_conversions import *
from scipy.optimize import minimize
import emcee
from orbit_solution import get_orbital_from_cartesian
from astropy import units as u
from astropy.coordinates import SkyCoord
from scipy import stats

# a function to handle rotations between the ecliptic and telesscope-centric reference frames
def rotate_coordinates(x, y, z, eq_to_ecl = True):

    transformation_matrix = np.array([[1.0,              0.0,             0.0],
                                      [0.0,  np.cos(epsilon), np.sin(epsilon)],
                                      [0.0, -np.sin(epsilon), np.cos(epsilon)]])
                                      
    if not eq_to_ecl: transformation_matrix = np.linalg.inv(transformation_matrix)

    x_new, y_new, z_new = transformation_matrix @ np.array([x, y, z])

    return x_new, y_new, z_new
    
def xyz_to_aei(x, y, z, vx, vy, vz, x0 = 0., y0 = 0., z0 = 0., vx0 = 0., vy0 = 0., vz0 = 0.):

    x, y, z = rotate_coordinates(x, y, z)
    vx, vy, vz = rotate_coordinates(vx, vy, vz)
    
    x += x0
    y += y0
    z += z0
    
    vx += vx0
    vy += vy0
    vz += vz0

    a, e, i, w, W, nu, M, EA, Tp = get_orbital_from_cartesian([x, y, z], [vx, vy, vz], mu = mu)
    
    return a, e, i, w, W, nu, M, EA, Tp

# the log-likelihood function
def log_likelihood(param, ts, RA_measures, Dec_measures, RA_errs, DEC_errs):

    # split our input param into its abg components
    x_eq, y_eq, z_eq, vx_eq, vy_eq, vz_eq = param

    RA_models = np.arctan2(y_eq + vy_eq * ts, x_eq + vx_eq * ts)
    Dec_models = np.arcsin((z_eq + vz_eq * ts) / np.sqrt((x_eq + vx_eq * ts)**2 + (y_eq + vy_eq * ts)**2 + (z_eq + vz_eq * ts)**2))

    r_eq = np.sqrt(x_eq**2 + y_eq**2 + z_eq**2)

    # the least-squares minimization prior
    chi_squared = np.sum((RA_measures - RA_models)**2 / RA_errs**2 + (Dec_measures - Dec_models)**2 / DEC_errs**2)

    # impose a contributing term in the LLH to push models towards the known distance
    distance_prior = (r_eq - r_guess)**2 / sigma_r**2
    
    x_ec, y_ec, z_ec = rotate_coordinates(x_eq, y_eq, z_eq)
    vx_ec, vy_ec, vz_ec = rotate_coordinates(vx_eq, vy_eq, vz_eq)
    
    x_ec += xE0
    y_ec += yE0
    z_ec += zE0
    
    '''
    vx_ec += vxE0
    vy_ec += vyE0
    vz_ec += vzE0
    '''
    
    r_vec, v_vec = [x_ec, y_ec, z_ec], [vx_ec, vy_ec, vz_ec]
    
    # it will be helpful to have these norms ahead of time
    r_ec = np.sqrt(np.dot(r_vec, r_vec))
    v_ec = np.sqrt(np.dot(v_vec, v_vec))

    v_rad = np.dot(r_vec, v_vec) / r_ec
    v_rad0 = 0.
    scale_parameter = 0.1 # this is the Cauchy gamma parameter
    
    # define our prior a the probability distribution function for a Cauchy distribution
    v_rad_prior = scale_parameter**2 / ((v_rad - v_rad0)**2 + scale_parameter**2) # this is scaled for peak = 1
    
    return -0.5 * (chi_squared + distance_prior) + np.log(v_rad_prior)

def log_prior(param, ts, RA_measures, Dec_measures, RA_errs, DEC_errs):
    
    # split our input param into its abg components
    x_eq, y_eq, z_eq, vx_eq, vy_eq, vz_eq = param

    aei = xyz_to_aei(x_eq, y_eq, z_eq, vx_eq, vy_eq, vz_eq, xE0, yE0, zE0)
    a, e = aei[0], aei[1]
    
    if e < 1. and a > 0.:
        return 0.0
    return -np.inf

# now, the total "log probability" combines these previous two
def log_probability(param, ts, RA_measures, Dec_measures, RA_errs, DEC_errs):

    # turn off if you have no hard-bound priors
    lp = log_prior(param, ts, RA_measures, Dec_measures, RA_errs, DEC_errs)
    
    if not np.isfinite(lp):

        return -np.inf
        
    return lp + log_likelihood(param, ts, RA_measures, Dec_measures, RA_errs, DEC_errs)

# install some global constants
SunGM       = 4. * np.pi**2 / 1.000037773533  # solar gravitation
MercuryGM   = 6.55371264e-06
VenusGM     = 9.66331433e-05
EarthMoonGM = 1.20026937e-04
MarsGM      = 1.27397978e-05
JupiterGM   = 3.76844407e-02 + 7.80e-6
SaturnGM    = 1.12830982e-02 + 2.79e-6
UranusGM    = 1.72348553e-03 + 0.18e-6
NeptuneGM   = 2.03318556e-03 + 0.43e-6

# combine for the total `mu=GM`; it's 0.13% more than the usual GM
mu = SunGM + MercuryGM + VenusGM + EarthMoonGM + MarsGM + JupiterGM + SaturnGM + UranusGM + NeptuneGM
nwalkers, nsteps, ndim = 150, 1500, 6
epsilon = 23.44 * np.pi / 180.
gbt_astrometric_error = 0.025 # arcseconds
jwst_astrometric_error = 0.005 # arcseconds
d_L2 = m_to_AU(1.5e9)

f = open('RADec_sample.txt', 'w')
f.write('time RA Dec sigma_RA sigma_Dec r_from_Earth sigma_r x_ssb sigma_x y_ssb sigma_y z_ssb sigma_z r_ssb sigma_r\n')

# define the test TNO
TNO = 'K13GD6Z'

# define the epochs for our Horizons query
epochs = {'start':'2015-01-01', 'stop':'2015-01-02', 'step':'6h'}

# get earth and JWST pos from Horizons here
gbt_statevectors = Horizons(id = '399', location = '500@0', epochs = epochs, id_type = 'majorbody').vectors()

# get the ecliptic statevector of Earth (gbt) w.r.t. barycenter in [AU, AU/year]
x_gbt, y_gbt, z_gbt, vx_gbt, vy_gbt, vz_gbt = np.array(gbt_statevectors['x']), np.array(gbt_statevectors['y']), np.array(gbt_statevectors['z']), np.array(gbt_statevectors['vx'] * 365.25), np.array(gbt_statevectors['vy'] * 365.25), np.array(gbt_statevectors['vz'] * 365.25)



xE0, yE0, zE0 = x_gbt[0], y_gbt[0], z_gbt[0]
vxE0, vyE0, vzE0 = vx_gbt[0], vy_gbt[0], vz_gbt[0]

# get the object from Horizons w.r.t. the barycenter
obj = Horizons(id = TNO, location = '500@0', epochs = epochs)#, id_type = 'majorbody')
q=obj.vectors()

x, y, z, vx, vy, vz = np.array(q['x']), np.array(q['y']), np.array(q['z']), np.array(q['vx'] * 365.25), np.array(q['vy'] * 365.25), np.array(q['vz'] * 365.25)

# get the object's true orbital elements from SSB
elements = obj.elements()[0]
true_elements = elements['a'], elements['e'], elements['q'], np.pi * elements['incl'] / 180., np.pi * elements['w'] / 180., np.pi * elements['Omega'] / 180.

print(true_elements)
# get true `z` distance between the object and observatory
statevector0 = obj.vectors()

r_true_from_earth = np.sqrt((statevector0['x'] - x_gbt)**2 + (statevector0['y'] - y_gbt)**2 + (statevector0['z'] - z_gbt)**2)
r_true_from_bary = np.sqrt((statevector0['x'])**2 + (statevector0['y'])**2 + (statevector0['z'])**2)
# define our sigma_z, and use it to make our z_guess more realistic, given a z_true
sigma_r = AU_to_pc(r_true_from_earth) * r_true_from_earth * np.sqrt(gbt_astrometric_error**2 + jwst_astrometric_error**2) / d_L2

r_guess = r_true_from_earth# + np.random.normal(0., sigma_r)

# do this from Subaru
obj_from_gbt = Horizons(id = TNO, location = '@399', epochs = epochs)#, id_type = 'majorbody')

# get RAs and Decs from each observatory
gbt_eph = obj_from_gbt.ephemerides()

# collect times [yr] and RA/Decs [rad]
ts = np.array(gbt_eph['datetime_jd']) / 365.25
ts -= ts[0] # initialize at t=0 for simplicity

# get the true (RA, Dec)s for our object
RAs = np.pi * np.array(gbt_eph['RA']) / 180.
Decs = np.pi * np.array(gbt_eph['DEC']) / 180.
print(RAs)

# generate line of gaussian errors with 1-sigma at the supplied astrometric error (note that this error might actually be generous, not conservative)
RA_errs = np.random.normal(0, arcsec_to_rad(gbt_astrometric_error), len(RAs))
Dec_errs = np.random.normal(0, arcsec_to_rad(gbt_astrometric_error), len(Decs))

# add the errors to our true values to simulate noise
#Decs += Dec_errs
#RAs += RA_errs / np.cos(Decs)

'''
sigma_x / x =
'''

x_eq = r_guess * np.cos(RAs) * np.cos(Decs)
y_eq = r_guess * np.sin(RAs) * np.cos(Decs)
z_eq = r_guess * np.sin(Decs)

x_ec, y_ec, z_ec = rotate_coordinates(x_eq, y_eq, z_eq)
x_ec += x_gbt
y_ec += y_gbt
z_ec += z_gbt

rec_xyz = np.array(x_ec), np.array(y_ec), np.array(z_ec)
true_xyz = np.array(statevector0['x']), np.array(statevector0['y']), np.array(statevector0['z'])

print(np.sqrt(rec_xyz[0]**2 + rec_xyz[1]**2 + rec_xyz[2]**2))
print(np.sqrt(true_xyz[0]**2 + true_xyz[1]**2 + true_xyz[2]**2))
print(true_elements[0])
print(1. / (2. / np.sqrt(x_ec**2 + y_ec**2 + z_ec**2) - (vx**2 + vy**2 + vz**2) / mu))
exit(1)


'''

print('ll')
for i in range(3):
    print(rec_xyz[i]/true_xyz[i])
exit(1)

fig, axs = plt.subplots(2, 2)
axs[0, 0].plot(rec_xyz[0], rec_xyz[2], label = 'recovered barycentric position from RA/Dec')
axs[0, 0].plot(true_xyz[0], true_xyz[2], label = 'HORIZONS (true barycentric position)')
axs[1, 0].set_xlabel('x [AU]')
axs[0, 0].set_ylabel('z [AU]')
axs[1, 0].plot(rec_xyz[0], rec_xyz[1])
axs[1, 0].plot(true_xyz[0], true_xyz[1])
axs[1, 0].set_ylabel('y [AU]')
axs[1, 1].plot(rec_xyz[2], rec_xyz[1])
axs[1, 1].plot(true_xyz[2], true_xyz[1])
axs[1, 1].set_xlabel('z [AU]')
axs[0, 0].legend()
plt.suptitle(TNO)

r_obs = np.sqrt(rec_xyz[0]**2 + rec_xyz[1]**2 + rec_xyz[2]**2)
r_true = np.sqrt(true_xyz[0]**2 + true_xyz[1]**2 + true_xyz[2]**2)

axs[0, 1].plot(ts * 365.25 * 24, 100 * (r_obs - r_true) / r_true)
axs[0, 1].set_ylabel('% error on distance')
axs[0, 1].set_xlabel('time [hours]')
plt.show()
exit(1)
'''

#delta_RA, delta_Dec = RAs[-1] - RAs[0], Decs[-1] - Decs[0]
#angular_vx, angular_vy = delta_RA / (ts[-1] - ts[0]), delta_Dec / (ts[-1] - ts[0])

# do this from Subaru
obj_from_gbt = Horizons(id = TNO, location = '@399', epochs = epochs)#, id_type = 'majorbody')

# get RAs and Decs from each observatory
gbt_eph = obj_from_gbt.ephemerides()

# collect times [yr] and RA/Decs [rad]
ts = np.array(gbt_eph['datetime_jd']) / 365.25
ts -= ts[0] # initialize at t=0 for simplicity

r_recs = []
v_recs = []
a_recs = []
x_recs = []
y_recs = []
z_recs = []

for i in range(10000):

    r_guess = np.array(r_true_from_earth[2] + np.random.normal(0., sigma_r[2]))

    # get the true (RA, Dec)s for our object
    RAs = np.pi * np.array(gbt_eph['RA']) / 180.
    Decs = np.pi * np.array(gbt_eph['DEC']) / 180.

    # generate line of gaussian errors with 1-sigma at the supplied astrometric error (note that this error might actually be generous, not conservative)
    RA_errs = np.random.normal(0, arcsec_to_rad(gbt_astrometric_error), len(RAs))
    Dec_errs = np.random.normal(0, arcsec_to_rad(gbt_astrometric_error), len(Decs))

    # add the errors to our true values to simulate noise
    Decs += Dec_errs
    RAs += RA_errs / np.cos(Decs)

    x_eq = r_guess * np.cos(RAs) * np.cos(Decs)
    y_eq = r_guess * np.sin(RAs) * np.cos(Decs)
    z_eq = r_guess * np.sin(Decs)

    x_ec, y_ec, z_ec = rotate_coordinates(x_eq, y_eq, z_eq)
    
    x_ec += x_gbt
    y_ec += y_gbt
    z_ec += z_gbt
    #x_ec = np.array(x_ec)
    #y_ec = np.array(y_ec)
    #z_ec = np.array(z_ec)
    r_ec = np.sqrt(x_ec**2 + y_ec**2 + z_ec**2)
    x_recs.append(np.mean(x_ec))
    y_recs.append(np.mean(y_ec))
    z_recs.append(np.mean(z_ec))
    r_recs.append(np.mean(np.sqrt(x_ec**2 + y_ec**2 + z_ec**2)))

for i in range(len(RAs)):
    if i == 2 or i == 3: continue
    f.write(str(ts[i]) + ' ' + str(RAs[i]) + ' ' + str(Decs[i]) + ' ' + str(0.025/206265.) + ' ' + str(0.025/206265.) + ' ' + str(r_guess) + ' ' + str(sigma_r[2]) + ' ' +  str(x_ec[i]) + ' ' + str(np.std(x_recs)) + ' ' +  str(y_ec[i]) + ' ' + str(np.std(y_recs)) + ' ' +  str(z_ec[i]) + ' ' + str(np.std(z_recs)) + ' ' +  str(r_ec[i]) + ' ' + str(np.std(r_recs)) + '\n')
    
print(np.min(r_recs), np.max(r_recs))
plt.hist(r_recs, histtype = 'step', label = r'$\mu=$' + str(round(np.mean(r_recs), 4)) + ', ' + r'$\sigma=$' + str(round(np.std(r_recs), 4)), lw = 2, color = 'darkblue', bins = 100)
plt.xlabel('r [AU]')
plt.axvline(x = np.mean(r_true_from_bary))
plt.legend()
plt.show()

plt.hist(v_recs, histtype = 'step', label = r'$\mu=$' + str(round(np.mean(v_recs), 4)) + ', ' + r'$\sigma=$' + str(round(np.std(v_recs), 4)), lw = 2, color = 'darkblue')
plt.legend()
plt.show()

plt.hist(a_recs, histtype = 'step', label = r'$\mu=$' + str(round(np.mean(a_recs), 4)) + ', ' + r'$\sigma=$' + str(round(np.std(a_recs), 4)), lw = 2, color = 'darkblue')
plt.legend()
plt.show()
exit(1)

'''
---
'''

x_guess = r_guess / np.sqrt(3.)
y_guess = r_guess / np.sqrt(3.)
z_guess = r_guess / np.sqrt(3.)
vx_guess = np.sqrt(mu / r_guess) / np.sqrt(3.)
vy_guess = np.sqrt(mu / r_guess) / np.sqrt(3.)
vz_guess = np.sqrt(mu / r_guess) / np.sqrt(3.)
print(vx_guess)
nll = lambda *args: -log_likelihood(*args)
initial = np.array([x_guess, y_guess, z_guess, vx_guess, vy_guess, vz_guess])
soln = minimize(nll, initial, args=(ts, RAs, Decs, np.ones_like(RA_errs) * arcsec_to_rad(gbt_astrometric_error), np.ones_like(RA_errs) * arcsec_to_rad(gbt_astrometric_error)))

pos = soln.x + 1. * np.random.randn(32, 6)
nwalkers, ndim = pos.shape

sampler = emcee.EnsembleSampler(nwalkers, ndim, log_probability, args=(ts, RAs, Decs, np.ones_like(RA_errs) * arcsec_to_rad(gbt_astrometric_error), np.ones_like(RA_errs) * arcsec_to_rad(gbt_astrometric_error)))
sampler.run_mcmc(pos, 10000, progress=True);

fig, axes = plt.subplots(6, figsize=(10, 7), sharex=True)
samples = sampler.get_chain()
labels = ["x", "y", "z", "vx", "vy", "vz"]
for i in range(ndim):
    ax = axes[i]
    ax.plot(samples[:, :, i], "k", alpha=0.3)
    ax.set_xlim(0, len(samples))
    ax.set_ylabel(labels[i])
    ax.yaxis.set_label_coords(-0.1, 0.5)

axes[-1].set_xlabel("step number")

plt.show()

print(soln.x)

