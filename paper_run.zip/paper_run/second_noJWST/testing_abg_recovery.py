import numpy as np, matplotlib.pyplot as plt
from astroquery.jplhorizons import Horizons

# get (l, b) from (RA, DEC)
def get_lb_from_RADEC(RA, DEC, epsilon = 23.44 * np.pi / 180.):

    l = np.arctan2((np.cos(epsilon) * np.cos(DEC) * np.sin(RA) + np.sin(epsilon) * np.sin(DEC)), (np.cos(DEC) * np.cos(RA)))
    b = np.arcsin(np.cos(epsilon) * np.sin(DEC) - np.sin(epsilon) * np.cos(DEC) * np.sin(RA))

    return l, b

# get (theta_xs, theta_ys) from (l, b)
def get_thetas_from_lb(l, b, l0 = 0., b0 = 0.):

    denominator = np.sin(b0) * np.sin(b) + np.cos(b0) * np.cos(b) * np.cos(l - l0)

    theta_xs = np.cos(b) * np.sin(l - l0) / denominator
    theta_ys = (np.cos(b0) * np.sin(b) - np.sin(b0) * np.cos(b) * np.cos(l - l0)) / denominator
    
    return theta_xs, theta_ys

# a function to handle rotations between the ecliptic and telesscope-centric reference frames
def rotate_coordinates(x, y, z, l0, b0, x0 = 0., y0 = 0., z0 = 0., reverse = False):

    # to telescopecentric
    if not reverse:

        transformation_matrix = np.array([[-np.sin(l0),              np.cos(l0),               0.0],
                                          [-np.cos(l0) * np.sin(b0), -np.sin(l0) * np.sin(b0), np.cos(b0)],
                                          [np.cos(l0) * np.cos(b0),  np.sin(l0) * np.cos(b0),  np.sin(b0)]])
    # to ecliptic
    else:

        transformation_matrix = np.array([[-np.sin(l0), -np.cos(l0) * np.sin(b0), np.cos(l0) * np.cos(b0)],
                                          [np.cos(l0),  -np.sin(l0) * np.sin(b0), np.sin(l0) * np.cos(b0)],
                                          [0.0,         np.cos(b0),               np.sin(b0)]])
    
    x_new, y_new, z_new = transformation_matrix @ np.array([x - x0, y - y0, z - z0])

    return x_new, y_new, z_new

# set some constants
mu = 39.52989778495525# / 365.25**2
epsilon = 23.44 * np.pi / 180.

# define the epochs for our Horizons query
epochs = {'start':'2021-01-01', 'stop':'2022-01-01', 'step':'10d'}

# choose some OSSOS object
OSSOS_object = 'K02GG6G'

'''
First, let's compute the theta values from the on-sky RA/Dec values
'''

# get the object from Earth
obj_from_earth = Horizons(id = OSSOS_object, location = '@399', epochs = epochs)

# get RAs and DECs from each observatory
eph_from_earth = obj_from_earth.ephemerides()

# collect times [yr] and RA/DECs [rad]
ts = np.array(eph_from_earth['datetime_jd']) / 365.25
ts -= ts[0] # initialize at t=0 for simplicity
RAs  = np.pi * np.array(eph_from_earth['RA'])  / 180. # in radians
DECs = np.pi * np.array(eph_from_earth['DEC']) / 180. # in radians

# convert from celestial to ecliptic coordinates, center the frame about our object's ecliptic origin
ls, bs = get_lb_from_RADEC(RAs, DECs)
l0 = ls[0] # centering at ls[0]
b0 = bs[0] # centering at bs[0]

# convert from ecliptic to tangent-plane projections
theta_xs_rec, theta_ys_rec = get_thetas_from_lb(ls, bs, l0, b0)

'''
Last, let's compute the theta values from the physical positions of objects in the solar system
'''

# get earth and JWST pos from Horizons here
earth_statevectors = Horizons(id = '399', location = '500@0', epochs = epochs, id_type = 'majorbody').vectors()

# get the ecliptic statevector of Earth (gbt) w.r.t. barycenter in [AU, AU/year]
x_earth, y_earth, z_earth = np.array(earth_statevectors['x']), np.array(earth_statevectors['y']), np.array(earth_statevectors['z'])

# get object from barycenter
obj = Horizons(id = OSSOS_object, location = '500@0', epochs = epochs)

obj_from_bary_statevectors = obj.vectors()
x_obj, y_obj, z_obj = obj_from_bary_statevectors['x'], obj_from_bary_statevectors['y'], obj_from_bary_statevectors['z']
vx_obj, vy_obj, vz_obj = obj_from_bary_statevectors['vx'], obj_from_bary_statevectors['vy'], obj_from_bary_statevectors['vz']

# convert from AU/d to AU/yr
#vx_obj *= 365.25
#vy_obj *= 365.25
#vz_obj *= 365.25

# create telescope-centric (`tele`) versions of the ecliptic (`ecl`) coords
x_tele, y_tele, z_tele = rotate_coordinates(x_earth, y_earth, z_earth, l0, b0, x_earth[0], y_earth[0], z_earth[0])

x_obj, y_obj, z_obj = rotate_coordinates(x_obj, y_obj, z_obj, l0, b0, x_earth[0], y_earth[0], z_earth[0])
vx_obj, vy_obj, vz_obj = rotate_coordinates(vx_obj, vy_obj, vz_obj, l0, b0)

# translate into alpha, beta, gamma from x, y, z
alpha = x_obj / z_obj
beta  = y_obj / z_obj
gamma =    1. / z_obj
adot = vx_obj / z_obj
bdot = vy_obj / z_obj
gdot = vz_obj / z_obj

# shorthand from Matt Holman (2018)'s paper
sigma = mu * gamma**3

tx_num = alpha + adot * ts + (-0.5 * sigma * ts**2 * alpha - 1./6 * sigma * ts**3 * (adot -3. * alpha * gdot)) - gamma * x_tele
ty_num =  beta + bdot * ts + (-0.5 * sigma * ts**2 * beta  - 1./6 * sigma * ts**3 * (bdot -3. *  beta * gdot)) - gamma * y_tele
tz_den =     1 + gdot * ts + (-0.5 * sigma * ts**2 * 1.    - 1./6 * sigma * ts**3 * (gdot -3. *    1. * gdot)) - gamma * z_tele

# compute the theta x and y values from the known positions of the objects in the solar system
tx_models = tx_num / tz_den
ty_models = ty_num / tz_den

# make plot to compare the theta values from 1) known RA and Dec values and 2) known spatial positions of the object
plt.plot(theta_xs_rec, theta_ys_rec, label = 'From RA/Dec')
plt.plot(tx_models, ty_models, label = 'From alpha/beta/gamma')
plt.legend()
plt.xlabel(r'$\theta_x$')
plt.ylabel(r'$\theta_y$')
plt.show()
print(ts)
plt.plot(ts, 206265*(theta_xs_rec - tx_models), label = r'$\theta_x$')
plt.plot(ts, 206265*(theta_ys_rec - ty_models), label = r'$\theta_y$')
plt.legend()
plt.xlabel('t [year]')
plt.ylabel(r'$\Delta\theta$' + ' [arcsec]')
plt.show()
