from __future__ import division
import numpy as np
import scipy.stats.kde as kde

def get_hpd1(sample, alpha):
    """Calculate highest posterior density (HPD) of array for given alpha.
    The HPD is the minimum width Bayesian credible interval (BCI).
    The function works for multimodal distributions, returning more than one mode
    Parameters
    ----------
    
    sample : Numpy array or python list
        An array containing MCMC samples
    alpha : float
        Desired probability of type I error (defaults to 0.05)
    Returns
    ----------
    hpd: array with the lower
          
    """
    sample = np.asarray(sample)
    sample = sample[~np.isnan(sample)]
    # get upper and lower bounds
    l = np.min(sample)
    u = np.max(sample)
    density = kde.gaussian_kde(sample)
    x = np.linspace(l, u, 2000)
    y = density.evaluate(x)
    #y = density.evaluate(x, l, u) waitting for PR to be accepted
    xy_zipped = zip(x, y / np.sum(y))
    xy = sorted(xy_zipped, key = lambda x: x[1], reverse = True)
    xy_cum_sum = 0
    hdv = []
    for val in xy:
        xy_cum_sum += val[1]
        hdv.append(val[0])
        if xy_cum_sum >= (1. - alpha):
            break
    hdv.sort()
    diff = (u - l) / 20.  # differences of 5%
    hpd = []
    hpd.append(min(hdv))
    for i in range(1, len(hdv)):
        if hdv[i] - hdv[i - 1] >= diff:
            hpd.append(hdv[i - 1])
            hpd.append(hdv[i])
    hpd.append(max(hdv))
    ite = iter(hpd)
    hpd = list(zip(ite, ite))
    modes = []
    for value in hpd:
         x_hpd = x[(x > value[0]) & (x < value[1])]
         y_hpd = y[(x > value[0]) & (x < value[1])]
         modes.append(x_hpd[np.argmax(y_hpd)])
    return modes, hpd
import matplotlib.pyplot as plt
# create a function to compute the highest posterior density of a distribution
# function finds all batchs of distribution which contain (1 - alpha) of the data, and reutrns the region which has the shortest length
def get_hpd(temp_sample, peak, alpha):

    '''
    temp_sample is the array of values for our distribution
    
    (1 - alpha) is the fraction of our distribution for which we want to contain
        ie, alpha = 0.31 means that we want to capture (1 - 0.31) = 0.69 or 69% of distribution
    '''

    # make a copy of our distribution so that alterations to this array don't affect the original
    sample = temp_sample.copy()

    lengths = []
    intervals = []

    # chains of this distribution are assumed not to be in order, but we'll want them to be
    sample.sort()

    # iterate over each of the samples
    for i in range(len(sample)):
    
        # an HPD that is (1 - alpha) wide can never begin beyond the `(1 - alpha) * len(sample)`th sample, so quit if we hit this
        # this is never an issue anyway for distributions whose peak is near the beginning, as ours will be
        if i + int((1 - alpha) * len(sample)) >= len(sample): break
        if (peak >= sample[i]) and (peak <= sample[i + int((1 - alpha) * len(sample))]): pass
        else: continue

        lengths.append(sample[i + int((1 - alpha) * len(sample))] - sample[i])
        intervals.append((sample[i], sample[i + int((1 - alpha) * len(sample))]))
        
    interval = intervals[np.argmin(lengths)]
    
    return interval
