#------------------------------------------------------------------------------#
#---------------------------------analysis.py----------------------------------#
#------------------------------------------------------------------------------#
#--------------------------Created by Mark Giovinazzi--------------------------#
#------------------------------------------------------------------------------#
#-----This program accepts a file of Right Ascenions, Declinations, their------#
#-astrometric errors, and times. It utilizes a Markov Chain Monte Carlo (MCMC)-#
#--from the emcee Python pacakge in order to fit the six parameters described--#
#--in Berstein et al. 2000: \alpha, \beta, \gamma, \dot{\alpha}, \dot{\beta},--#
#--\dot{gamma}. The purpose of this project is to motivate the reconstruction--#
#--of Trans-Neptunian Objects (TNOs) from a small number of observations. We---#
#---believe this can be done efficiently using JWST as a second observatory,---#
#-with which future proposals will be able to take advantage of a single-epoch-#
#-parallax measurement, instantaneously determining \gamma and thereby working-#
#---to collapse the parameter space of our MCMC algorithm, allowng for quick---#
#-------and accurate orbital reconstruction for any solar system object--------#
#------------------------------------------------------------------------------#
#---------------------------Date Created: 11/09/2020---------------------------#
#------------------------Date Last Modified: 12/28/2020------------------------#
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
#-------------------------------Import Libraries-------------------------------#
#------------------------------------------------------------------------------#
import numpy as np, matplotlib.pyplot as plt
import os, math, time, pickle, random
from orbit_solution import *
from util import *
from unit_conversions import *
from astrometric_conversions import *
from earth_simulator import *
from scipy.stats import binned_statistic
from scipy.stats import linregress
from astropy.coordinates import SkyCoord
from astropy import units as u
from operator import itemgetter
from scipy.optimize import least_squares
from scipy.optimize import minimize
import emcee
import corner
from multiprocessing import Pool # to parralelize our MCMC
from astroquery.jplhorizons import Horizons
from astropy.io import ascii

os.environ["OMP_NUM_THREADS"] = "40"

N_epochs = 30
firstorsecond = 2

'''
first set up all the functions we'll need
'''

# get (l, b) from (RA, DEC)
def get_lb_from_RADEC(RA, DEC, epsilon = 23.4392911112 * np.pi / 180.):

    l = np.arctan2((np.cos(epsilon) * np.cos(DEC) * np.sin(RA) + np.sin(epsilon) * np.sin(DEC)), (np.cos(DEC) * np.cos(RA)))
    b = np.arcsin(np.cos(epsilon) * np.sin(DEC) - np.sin(epsilon) * np.cos(DEC) * np.sin(RA))

    return l, b

# get (theta_xs, theta_ys) from (l, b)
def get_thetas_from_lb(l, b, l0 = 0., b0 = 0.):

    denominator = np.sin(b0) * np.sin(b) + np.cos(b0) * np.cos(b) * np.cos(l - l0)

    theta_xs = np.cos(b) * np.sin(l - l0) / denominator
    theta_ys = (np.cos(b0) * np.sin(b) - np.sin(b0) * np.cos(b) * np.cos(l - l0)) / denominator
    
    return theta_xs, theta_ys

# the log-likelihood function
def log_likelihood2(param, ts, tx_measures, ty_measures, RA_errs, DEC_errs, delta_gamma, use_JWST = True, x_obs = 0, y_obs = 0, z_obs = 0):

    # split our input param into its abg components
    alpha, adot, beta, bdot, gamma, gdot = param
    
    # immediately convert our abg param into an aei (Keplerian; orbital) elements
    aei = abg_to_aei(param, -xs_ecl[0], -ys_ecl[0], -zs_ecl[0])

    # if the orbit is unbound, we do not need to proceed -- weight this trial at -inf and move on
    if aei[1] > 0.99 or aei[0] < 1: return -np.inf
    
    # shorthand from Matt Holman (2018)'s paper
    sigma = mu * gamma**3
    
    # linear gravitational perturbation term from Holman et al. (2018)
    gamma_g = -0.5 * sigma * ts**2 * np.array([alpha, beta, 1.])[:, None] - 1./6 * sigma * ts**3 * gdot * (np.array([adot, bdot, gdot])[:, None] - 3. * np.array([alpha, beta, 1.])[:, None])

    # derive tangent-plane projection models from our input model param; equations from Bernstein et al. (2000)
    tx_num = alpha + adot * ts + gamma_g[0] - gamma * x_obs
    ty_num =  beta + bdot * ts + gamma_g[1] - gamma * y_obs
    tz_den =     1 + gdot * ts + gamma_g[2] - gamma * z_obs
    
    #
    tx_models = tx_num / tz_den
    ty_models = ty_num / tz_den
    
    b = 4

    # our three chi squared functions for the overall log-likelihood
    chi_squared_bind = b * (adot**2 + bdot**2 + gdot**2) / (2. * mu * gamma**3) # the binding chi squared
    chi_squared_gamma = (gamma - gamma_guess)**2 / delta_gamma**2 # the "how well do I know the distance?" prior
    chi_squared_least_squares = np.sum((tx_measures - tx_models)**2 / RA_errs**2 + (ty_measures - ty_models)**2 / DEC_errs**2) # the least-squares minimization prior

    # if we don't have an obs from JWST, we should replace chi_squared gamma in the following way
    if not use_JWST: chi_squared_gamma = -(gamma - 1. / 40)**2 / (2 * (0.25 * 1. / 40)**2)

    # sum them up into one overall term
    return chi_squared_bind, chi_squared_gamma, chi_squared_least_squares

# the log-likelihood function
def log_likelihood(param, ts, tx_measures, ty_measures, RA_errs, DEC_errs, delta_gamma, use_JWST = True, x_obs = 0, y_obs = 0, z_obs = 0):

    # split our input param into its abg components
    alpha, adot, beta, bdot, gamma, gdot = param
    
    # immediately convert our abg param into an aei (Keplerian; orbital) elements
    aei = abg_to_aei(param, -xs_ecl[0], -ys_ecl[0], -zs_ecl[0])

    # if the orbit is unbound, we do not need to proceed -- weight this trial at -inf and move on
    if aei[1] > 0.99 or aei[0] < 1: return -np.inf
    
    # shorthand from Matt Holman (2018)'s paper
    sigma = mu * gamma**3
    
    # linear gravitational perturbation term from Holman et al. (2018)
    gamma_g = -0.5 * sigma * ts**2 * np.array([alpha, beta, 1.])[:, None] - 1./6 * sigma * ts**3 * (np.array([adot, bdot, gdot])[:, None] - 3. * np.array([alpha, beta, 1.])[:, None]) * gdot

    # derive tangent-plane projection models from our input model param; equations from Bernstein et al. (2000)
    tx_num = alpha + adot * ts + gamma_g[0] - gamma * x_obs
    ty_num =  beta + bdot * ts + gamma_g[1] - gamma * y_obs
    tz_den =     1 + gdot * ts + gamma_g[2] - gamma * z_obs
    
    #
    tx_models = tx_num / tz_den
    ty_models = ty_num / tz_den
    
    b = 4

    # our three chi squared functions for the overall log-likelihood
    chi_squared_bind = b * (adot**2 + bdot**2 + gdot**2) / (2. * mu * gamma**3) # the binding chi squared
    chi_squared_gamma = (gamma - gamma_guess)**2 / delta_gamma**2 # the "how well do I know the distance?" prior
    chi_squared_least_squares = np.sum((tx_measures - tx_models)**2 / RA_errs**2 + (ty_measures - ty_models)**2 / DEC_errs**2) # the least-squares minimization prior

    # if we don't have an obs from JWST, we should replace chi_squared gamma in the following way
    if not use_JWST: chi_squared_gamma = -(gamma - 1. / 40)**2 / (2 * (0.25 * 1. / 40)**2)

    # sum them up into one overall term
    chi_squared = chi_squared_bind + chi_squared_gamma + chi_squared_least_squares

    # the -log-likelihood results in -0.5 * chi squared
    return -0.5 * chi_squared

def log_prior(param, delta_gamma, use_JWST = True, x_obs = 0, y_obs = 0, z_obs = 0):
    
    # split our input param into its abg components
    alpha, adot, beta, bdot, gamma, gdot = param
    
    # this term gets turned on if the observatory is *not* the SSB
    elongation_term = (1. - 2 * gamma * np.cos(Beta0) + gamma**2)**-0.5
    
    # compute the energy for the proposed orbit
    E = -mu * gamma * elongation_term + (adot**2 + bdot**2 + gdot**2) / ( 2 * gamma**2)
    E_min = np.min(E) # this is done in case E is a list, which is the case for the geocentric scenario
    
    x, y, z = alpha / gamma, beta / gamma, 1. / gamma
    vx, vy, vz = adot / gamma, bdot / gamma, gdot / gamma

    # to ecliptic
    x, y, z = rotate_coordinates(x, y, z, l0, b0, reverse = True)
    vx, vy, vz = rotate_coordinates(vx, vy, vz, l0, b0, reverse = True)
    
    # adding on ecliptic
    x -= xs_ecl[0]
    y -= ys_ecl[0]
    z -= zs_ecl[0]
    
    r_vec, v_vec = [x, y, z], [vx, vy, vz]
    
    # it will be helpful to have these norms ahead of time
    r = np.sqrt(np.dot(r_vec, r_vec))

    # compute semi major axis
    a = 1. / (2. / r - np.dot(v_vec, v_vec) / mu)
    
    if E_min < 0 and a < 100000. and a > 1.:# and gamma <= (gamma_guess + delta_gamma/gamma_guess) and gamma >= (gamma_guess - delta_gamma/gamma_guess):# and (gdot**2 <= gbs_min):# and gamma > 0.001 and gamma < 1:#(gdot**2 <= gamma_bind_squared):

        if not use_JWST:
            
            if gamma > 0.001 and gamma < 0.1:
            
                return 0.0
                
            else:
            
                return -np.inf

        return 0.0

    return -np.inf

# now, the total "log probability" combines these previous two
def log_probability(param, ts, tx_measures, ty_measures, RA_errs, DEC_errs, delta_gamma, use_JWST = True, x_obs = 0., y_obs = 0., z_obs = 0.):

    # turn off if you have no hard-bound priors
    lp = log_prior(param, delta_gamma, use_JWST, x_obs, y_obs, z_obs)
    
    if not np.isfinite(lp):

        return -np.inf
        
    return lp + log_likelihood(param, ts, tx_measures, ty_measures, RA_errs, DEC_errs, delta_gamma, use_JWST, x_obs, y_obs, z_obs)
    
# a function to handle rotations between the ecliptic and telesscope-centric reference frames
def rotate_coordinates(x, y, z, l0, b0, x0 = 0., y0 = 0., z0 = 0., reverse = False):

    # to telescopecentric
    if not reverse:

        transformation_matrix = np.array([[-np.sin(l0),              np.cos(l0),               0.0],
                                          [-np.cos(l0) * np.sin(b0), -np.sin(l0) * np.sin(b0), np.cos(b0)],
                                          [np.cos(l0) * np.cos(b0),  np.sin(l0) * np.cos(b0),  np.sin(b0)]])
    # to ecliptic
    else:

        transformation_matrix = np.array([[-np.sin(l0), -np.cos(l0) * np.sin(b0), np.cos(l0) * np.cos(b0)],
                                          [np.cos(l0),  -np.sin(l0) * np.sin(b0), np.sin(l0) * np.cos(b0)],
                                          [0.0,         np.cos(b0),               np.sin(b0)]])

    x_new, y_new, z_new = transformation_matrix @ np.array([x - x0, y - y0, z - z0])

    return x_new, y_new, z_new
    
# define a function to convert our telescopecentric coordinates to keplerian
def abg_to_aei(abg, x0 = 0., y0 = 0., z0 = 0., vx0 = 0., vy0 = 0., vz0 = 0.):

    alpha, adot, beta, bdot, gamma, gdot = abg
    
    x, y, z = alpha / gamma, beta / gamma, 1. / gamma
    vx, vy, vz = adot / gamma, bdot / gamma, gdot / gamma
    
    # move into barycentric ecliptic coordinates
    x, y, z = rotate_coordinates(x, y, z, l0, b0, reverse = True)
    vx, vy, vz = rotate_coordinates(vx, vy, vz, l0, b0, reverse = True)
    
    # x, y, z are now back in barycenter
    x += x0
    y += y0
    z += z0
    
    a, e, i, w, W, nu, M, EA, Tp = get_orbital_from_cartesian([x, y, z], [vx, vy, vz], mu = mu)
    
    return a, e, i, w, W, nu, M, EA, Tp
    
def get_distance_from_obj(obj, xE, yE, zE):

    statevector0 = obj.vectors()[0]

    distance = np.sqrt((statevector0['x'] - xE)**2 + (statevector0['y'] - yE)**2 + (statevector0['z'] - zE)**2)

    return distance

# function to accept an observable array and return the same array but with only select indices which we use to observe
def get_observing_inds(input_arr, n):

    '''
        The following observing strategy will be more than sufficient to track an object, but not overkill.
        
        for nobs in range(1, Nobs + 1):
        
            if       nobs == 1: type = TRIPLET
            elif nobs % 2 == 0: type = DOUBLET
            elif nobs % 2 == 1: type = SINGLET
    '''

    # this gets the indices which would make exclusively singlet observations
    inds_perm = list(input_arr.argsort()[::n])
    inds_temp = inds_perm.copy()

    # only our first observaiton needs to be a triplet; this will offer enough tracking information
    inds_temp.append(int(inds_temp[0] + obs_sep**2 / data_sep)) # add our first obs
    inds_temp.append(int(inds_temp[0] + 2 * obs_sep**2 / data_sep)) # add our second obs, completing the triplet
    
    # add in the doublets for n % 2 == 0 here
    for ind in range(len(inds_perm))[1::2]:
    
        inds_temp.append(int(inds_temp[ind] + obs_sep**2 / data_sep))

    # it's cleaner to just report the `inds` in order of occurence/observation
    return sorted(inds_temp)
    
# a function to simplify the itemization of applying indices to our arrays
def itemize_arr(arr_to_itemize, inds):

    # gets specifc set of elements from array
    return np.array(itemgetter(*inds)(arr_to_itemize))
    
#------------------------------------------------------------------------------#
#---------------------------------Main Program---------------------------------#
#------------------------------------------------------------------------------#
 
# setting a random seed is very useful for reproducing results
#np.random.seed(seed = 100)
 
# install some global constants
mu = 4 * np.pi**2 # mu = GM; [GM] = AU / yr
data_dir = 'MCMC_grid_data'
nwalkers, nsteps, ndim = 250, 5000, 6
use_JWST = True
epsilon = 23.4392911112 * np.pi / 180.
gbt_astrometric_error = 0.025 # arcseconds
jwst_astrometric_error = 0.005 # arcseconds
d_L2 = m_to_AU(1.5e9)

''' WHICH PLOTS TO MAKE '''
make_celestial_plots = False
make_corner_plots = False
make_convergence_plots = True
write_posteriors_separately = False

# we can collect all the data from 237 OSSOS objects with MPC designations here
OSSOS_objects_data = ascii.read('OSSOS_B.CDS')#[1::5] # just take every 5th object! -- plot below shows this is a very representative sample!

OSSOS_objects_data_subset = OSSOS_objects_data[1::5]
OSSOS_objects_data_subset.remove_row(41)
OSSOS_objects_data_subset.add_row(OSSOS_objects_data[172])
OSSOS_objects_data_subset.add_row(OSSOS_objects_data[49])
OSSOS_objects_data_subset.add_row(OSSOS_objects_data[10])

'''
plt.scatter(OSSOS_objects_data['a'], OSSOS_objects_data['e'], label = 'All (' + str(len(OSSOS_objects_data['e'])) + ' objects)', alpha = 0.5)
plt.scatter(OSSOS_objects_data_subset['a'], OSSOS_objects_data_subset['e'], label = 'Subset (' + str(len(OSSOS_objects_data_subset['e'])) + ' objects)')
plt.legend()
plt.xlabel('a [AU]')
plt.ylabel('e')
plt.title('OSSOS Objects with MPC Designation')
plt.savefig('OSSOS_object_sample.png', dpi = 500)
'''

# given that we are using Horizons as the template for data acquisition, we only need the OSSOS target list -- get that here!
OSSOS_objects = np.array(OSSOS_objects_data_subset['MPC'])

if firstorsecond == 1: OSSOS_objects = OSSOS_objects[:25]
elif firstorsecond == 2: OSSOS_objects = OSSOS_objects[25:]

# this convention will be useful for saving off output files
if use_JWST: JWST_str = ''
else: JWST_str = '_noJWST'

data_sep = 1. # number of hours separating each data point in the read-in Horizons data
obs_sep = 1. # number of hours between each obs in a triplet/doublet; give in hours

# decide if you want posteriors in abg- or aei-space (both may be set to true if you wish)
abg_post = True#False
aei_post = False#True
abg_labels = ["alpha", "adot", "beta", "bdot", "gamma", "gdot"]
aei_labels = ["a [AU]", "e", "q [AU]", "i [rad]", "w [rad]", "W [rad]"]

# create a file to track erros on perihelion
if not os.path.exists(os.path.join('MCMC_grid_data', 'perihelion_data' + JWST_str + '.txt')):

    perihelion_datafile = open(os.path.join('MCMC_grid_data', 'perihelion_data' + JWST_str + '.txt'), 'w')
    perihelion_datafile.write('OSSOS_object arc epochs obs sigma_a/a sigma_e/e sigma_q/q a e q i w W chi_squared_bind chi_squared_gamma chi_squared_ls\n')
    perihelion_datafile.flush()
    
else:

    perihelion_datafile = open(os.path.join('MCMC_grid_data', 'perihelion_data' + JWST_str + '.txt'), 'a')
    perihelion_datafile.flush()
    
# which arc lengths to loop over
arc_lengths = ['1mo', '1.5mo', '2mo', '2.5mo', '3mo', '3.5mo', '4mo', '4.5mo', '5mo', '5.5mo', '6mo', '6.5mo', '7mo', '7.5mo', '8mo', '8.5mo', '9mo', '9.5mo', '10mo'] # let 1mo == 30 days

# or choose number of epochs
num_epochs = [N_epochs]

# define the epochs for our Horizons query
epochs = {'start':'2021-01-01', 'stop':'2021-11-01', 'step':'1h'}

# get earth and JWST pos from Horizons here
gbt_statevectors = Horizons(id = '399', location = '500@0', epochs = epochs, id_type = 'majorbody').vectors()

# get the ecliptic statevector of Earth (gbt) w.r.t. barycenter in [AU, AU/year]
x_gbt, y_gbt, z_gbt, vx_gbt, vy_gbt, vz_gbt = np.array(gbt_statevectors['x']), np.array(gbt_statevectors['y']), np.array(gbt_statevectors['z']), np.array(gbt_statevectors['vx'] * 365.25), np.array(gbt_statevectors['vy'] * 365.25), np.array(gbt_statevectors['vz'] * 365.25)

# open an object file to track objects which can't be found in Horizons
if not os.path.exists('obj_file.txt'):

    obj_file = open('obj_file.txt', 'w')
    obj_file.write('Broken Objects\n')
    obj_file.flush()

# create index which tracks number of iterations completed; useful in case of break midway through
counter = 0

# create file to continuously track the `counter` variable
if os.path.exists('count_file.txt'):

    counted = int(open('count_file.txt', 'r').readlines()[0]) - 1

else:

    counted = 0
    
if counted != 0: is_recovery_val_necessary = True
else: is_recovery_val_necessary = False

counter += counted

# top loop is to move through varying epochs, or nights to observe over
for epoch in num_epochs[int(counted / (len(OSSOS_objects) * len(arc_lengths))):]:

    # loop over all selected objects
    for OSSOS_object in OSSOS_objects[int(counted / len(arc_lengths)):]:
    
        # try to get the object from Horizons. if it fails, make a note of which object broke
        try: obj = Horizons(id = OSSOS_object, location = '500@0', epochs = epochs)
        except: obj_file.write(OSSOS_object + '\n'); obj_file.flush(); counter += len(arc_lengths); continue
        
        # get the object's true orbital elements from SSB
        elements = obj.elements()[0]
        true_elements = elements['a'], elements['e'], elements['q'], np.pi * elements['incl'] / 180., np.pi * elements['w'] / 180., np.pi * elements['Omega'] / 180.
        
        # do this nfrom Subaru and JWST
        obj_from_gbt = Horizons(id = OSSOS_object, location = {'lon': 204.524, 'lat': 19.8255, 'elevation': 4.1602}, epochs = epochs)
        
        # get true `z` distance between the object and observatory
        z_true = get_distance_from_obj(obj, x_gbt[0], y_gbt[0], z_gbt[0])
        
        # get RAs and DECs from each observatory
        gbt_eph = obj_from_gbt.ephemerides()
        Beta0 = np.pi * gbt_eph['elong'][0] / 180.
        
        # a flag useful in case of midway crash
        if is_recovery_val_necessary: recovery_val = int(counted % (len(arc_lengths))); is_recovery_val_necessary = False
        else: recovery_val = 0
        
        # top level is to pick arc length of our object -- current max given data is 4 months
        for arc_length in arc_lengths[recovery_val:]:
        
            # starting the next run, so add 1!
            counter += 1
            
            # open a counter file to track which OSSOS object we are on, in case we ever break out
            count_file = open(os.path.join('count_file.txt'), 'w')
            count_file.write(str(counter))
            count_file.flush()
            
            # define out sigma_z, and use it to make our z_guess more realistic, given a z_true
            sigma_z = AU_to_pc(z_true) * z_true * gbt_astrometric_error / d_L2
            z_guess = z_true + np.random.normal(0., sigma_z)
            
            # otherwise, if we aren't using JWST, z=50 AU is probably a fair guess
            if not use_JWST: z_guess = 50.
            
            # collect times [yr] and RA/DECs [rad]
            ts = np.array(gbt_eph['datetime_jd']) / 365.25
            ts -= ts[0] # initialize at t=0 for simplicity
            RAs = np.pi * np.array(gbt_eph['RA']) / 180.
            DECs = np.pi * np.array(gbt_eph['DEC']) / 180.

            # create simmed celestial coordinates for JWST; idea is they can be translated
            RAs_jwst = RAs.copy()
            DECs_jwst = DECs.copy()

            # determine our time step
            dt = ts[1] - ts[0]
            
            # generate line of gaussian errors with 1-sgima at the supplied astrometric error (note that this error might actually be generous, not conservative)
            RA_errs = np.random.normal(0, arcsec_to_rad(gbt_astrometric_error), len(RAs))
            DEC_errs = np.random.normal(0, arcsec_to_rad(gbt_astrometric_error), len(DECs))

            RA_errs_jwst = np.random.normal(0, arcsec_to_rad(jwst_astrometric_error), len(RAs_jwst))
            DEC_errs_jwst = np.random.normal(0, arcsec_to_rad(jwst_astrometric_error), len(DECs_jwst))

            # add errors (this is, in fact, what we should be doing when using Horizons ephemerides!)
            DECs += DEC_errs
            RAs += RA_errs / np.cos(DECs)
            
            # we do DECs first since the appending of errors to RA is dependent on DEC
            DECs_jwst += DEC_errs_jwst
            RAs_jwst += RA_errs_jwst / np.cos(DECs_jwst)
        
            # print statement to tell which run we're on
            print('Run ' + str(counter) + '/' + str(int(len(num_epochs) * len(OSSOS_objects) * len(arc_lengths))))
        
            # define a string which will be unique to this round of variables
            grid_key = OSSOS_object + '_' + arc_length + '_' + str(epoch).zfill(2) + 'epoch'
        
            # convert `arc_length` to years, then divide by `dt`
            if   arc_length == '1mo':   N =  30. / 365.25 / dt
            elif arc_length == '1.5mo': N =  45. / 365.25 / dt
            elif arc_length == '2mo':   N =  60. / 365.25 / dt
            elif arc_length == '2.5mo': N =  75. / 365.25 / dt
            elif arc_length == '3mo':   N =  90. / 365.25 / dt
            elif arc_length == '3.5mo': N = 105. / 365.25 / dt
            elif arc_length == '4mo':   N = 120. / 365.25 / dt
            elif arc_length == '4.5mo': N = 135. / 365.25 / dt
            elif arc_length == '5mo':   N = 150. / 365.25 / dt
            elif arc_length == '5.5mo': N = 165. / 365.25 / dt
            elif arc_length == '6mo':   N = 180. / 365.25 / dt
            elif arc_length == '6.5mo': N = 195. / 365.25 / dt
            elif arc_length == '7mo':   N = 210. / 365.25 / dt
            elif arc_length == '7.5mo': N = 225. / 365.25 / dt
            elif arc_length == '8mo':   N = 240. / 365.25 / dt
            elif arc_length == '8.5mo': N = 255. / 365.25 / dt
            elif arc_length == '9mo':   N = 270. / 365.25 / dt
            elif arc_length == '9.5mo': N = 285. / 365.25 / dt
            elif arc_length == '10mo':  N = 300. / 365.25 / dt

            # hold onto this number!
            num_indices_in_arc = int(round(N)) + 1
            
            # the following pads the end of our observations to account for the epoch's plurality of obs
            N += 16 * obs_sep**2 / data_sep # the 2 adds a little extra padding
            
            # convert N to an integer for slicing purposes
            N = int(round(N)) + 1

            # cut all of our arrays by the appropriate amount, but store them in `cut` lists so we don't overwrite!
            ts_cut = ts[:N]
            RAs_cut = RAs[:N]
            DECs_cut = DECs[:N]
            RA_errs_cut = RA_errs[:N]
            DEC_errs_cut = DEC_errs[:N]
            xs_cut = x_gbt[:N]
            ys_cut = y_gbt[:N]
            zs_cut = z_gbt[:N]
            vxs_cut = vx_gbt[:N]
            vys_cut = vy_gbt[:N]
            vzs_cut = vz_gbt[:N]
            RAs_jwst_cut = RAs_jwst[:N]
            DECs_jwst_cut = DECs_jwst[:N]
            RA_errs_jwst_cut = RA_errs_jwst[:N]
            DEC_errs_jwst_cut = DEC_errs_jwst[:N]
            
            n = num_indices_in_arc / (epoch - 1)
            
            # convert n to an integer for slicing purposes
            n = int(round(n))
            
            # for getting the appropriate observing indices, it's important to use `ts_cut` since they are already in order
            inds = get_observing_inds(ts_cut, n)

            # apply the new `inds` to grab the specific observables we want using our designated observing stretaegy
            ts_ecl = itemize_arr(ts_cut, inds)
            RAs_ecl = itemize_arr(RAs_cut, inds)
            DECs_ecl = itemize_arr(DECs_cut, inds)
            RA_errs_ecl = itemize_arr(RA_errs_cut, inds)
            DEC_errs_ecl = itemize_arr(DEC_errs_cut, inds)
            xs_ecl = itemize_arr(xs_cut, inds)
            ys_ecl = itemize_arr(ys_cut, inds)
            zs_ecl = itemize_arr(zs_cut, inds)
            vxs_ecl = itemize_arr(vxs_cut, inds)
            vys_ecl = itemize_arr(vys_cut, inds)
            vzs_ecl = itemize_arr(vzs_cut, inds)
            RAs_jwst_ecl = itemize_arr(RAs_jwst_cut, inds)
            DECs_jwst_ecl = itemize_arr(DECs_jwst_cut, inds)
            RA_errs_jwst_ecl = itemize_arr(RA_errs_jwst_cut, inds)
            DEC_errs_jwst_ecl = itemize_arr(DEC_errs_jwst_cut, inds)
            
            # get midpoint of inds for the singular jwst observation
            jwst_ind = round(len(ts_cut) / 2.)
            
            def append_jwst_obs(arr0, arr1, ind):
            
                return np.append(arr0, arr1[ind])
            
            # add in the (translated) JWST observation to the list of gbt-observations
            ts_ecl = append_jwst_obs(ts_ecl, ts_cut, jwst_ind)
            RAs_ecl = append_jwst_obs(RAs_jwst_ecl, RAs_jwst_cut, jwst_ind)
            DECs_ecl = append_jwst_obs(DECs_jwst_ecl, DECs_jwst_cut, jwst_ind)
            RA_errs_ecl = append_jwst_obs(RA_errs_ecl, RA_errs_jwst_cut, jwst_ind)
            DEC_errs_ecl = append_jwst_obs(DEC_errs_ecl, DEC_errs_jwst_cut, jwst_ind)
            xs_ecl = append_jwst_obs(xs_ecl, xs_cut, jwst_ind)
            ys_ecl = append_jwst_obs(ys_ecl, ys_cut, jwst_ind)
            zs_ecl = append_jwst_obs(zs_ecl, zs_cut, jwst_ind)
            vxs_ecl = append_jwst_obs(vxs_ecl, vxs_cut, jwst_ind)
            vys_ecl = append_jwst_obs(vys_ecl, vys_cut, jwst_ind)
            vzs_ecl = append_jwst_obs(vzs_ecl, vzs_cut, jwst_ind)
            inds = np.append(inds, jwst_ind)

            if make_celestial_plots:
            
                # make the celestial plot
                m = (np.sqrt(RAs_cut[-1]**2 + DECs_cut[-1]**2) - np.sqrt(RAs_cut[0]**2 + DECs_cut[0]**2)) / (ts_cut[-1] - ts_cut[0])
                b = np.sqrt(RAs_cut[0]**2 + DECs_cut[0]**2)
                ys = m * ts_cut + b
                plt.plot(ts_cut*365.25, np.sqrt(RAs_cut**2 + DECs_cut**2) / ys, label = OSSOS_object + '\'s Path')
                plt.scatter(ts_ecl * 365.25, np.sqrt(RAs_ecl**2 + DECs_ecl**2) / np.array(itemgetter(*inds)(ys)), color = 'black', s = 0.5, zorder = 10, label = 'Ground Observations')
                plt.scatter(ts_ecl[-1] * 365.25, np.sqrt(RAs_ecl[-1]**2 + DECs_ecl[-1]**2) / np.array(itemgetter(*[jwst_ind])(ys)), color = 'orange', s = 0.5, zorder = 10, label = 'JWST Observation')
                plt.xlabel('Time [days]')
                plt.ylabel('Residual on sqrt(RA^2 + DEC^2)')
                plt.title('Arc Length=' + arc_length + ' (' + str(int(len(ts_ecl))) + ' obs)')
                plt.legend(loc = 'lower right')
                plt.savefig(os.path.join('MCMC_grid_data', 'celestial_plots', grid_key + '_residual' + JWST_str + '.png'), dpi = 500)
                plt.close('all')

            # open a results file for results specific to each sweep of our grid_key
            if write_posteriors_separately:
            
                results_file = open(os.path.join('MCMC_grid_data', 'posterior_results', grid_key + '_results' + JWST_str + '.txt'), 'wb')

            # convert from celestial to ecliptic coordinates, center the frame about our object's ecliptic origin
            ls, bs = get_lb_from_RADEC(RAs_ecl, DECs_ecl)
            l0 = ls[0] # centering at l[0]
            b0 = bs[0] # centering at b[0]

            # convert from ecliptic to tangent-plane projections
            theta_xs_rec, theta_ys_rec = get_thetas_from_lb(ls, bs, l0, b0)
            
            # give initial guesses for what xyz and their vs should be
            x_guess, y_guess = 0.0, 0.0

            # give initial guesses for alpha, beta, gamma, adot, bdot, gdot
            alpha_guess = x_guess / z_guess
            beta_guess  = y_guess / z_guess
            gamma_guess = 1. / z_guess
            adot_guess  = 2 * np.pi * gamma_guess**1.5 / np.sqrt(3) # this prior from section 2.3 in Bernstein et al. 2000
            bdot_guess  = 2 * np.pi * gamma_guess**1.5 / np.sqrt(3)
            gdot_guess  = 2 * np.pi * gamma_guess**1.5 / np.sqrt(3) # if nearly circular, then it's gamma**2.5
            
            # give the % error 1-std uncertainties we have in our distance
            delta_gamma = AU_to_pc(z_guess) * gbt_astrometric_error / d_L2 * gamma_guess

            '''
            now get to the optimization
            '''
            
            # create telescope-centric (`tele`) versions of the ecliptic (`ecl`) coords
            x_tele, y_tele, z_tele = rotate_coordinates(xs_ecl, ys_ecl, zs_ecl, l0, b0, xs_ecl[0], ys_ecl[0], zs_ecl[0])
            
            # call our negative log likelihood (nll) function, and initialize our guesses based on physical intuition
            nll = lambda *args: -log_likelihood(*args)
            initial = np.array([alpha_guess, adot_guess, beta_guess, bdot_guess, gamma_guess, gdot_guess])

            # take a quick approach using SciPy to minimize the function which will try doing a slightly better job
            soln = minimize(nll, initial, args = (ts_ecl, theta_xs_rec, theta_ys_rec, RA_errs_ecl, DEC_errs_ecl, delta_gamma, use_JWST, x_tele, y_tele, z_tele), tol = 1e-12)#, ftol = 1e-15, xtol = 1e-15, gtol = 1e-15)#, max_nfev = 10000)
            
            # These scale factors are where you need the work!
            scale = 1e-12

            # assign intial positions of walkers in some small gaussian ball centered at computed solution
            pos = soln.x + np.random.randn(nwalkers, ndim) * scale

            # run our MCMC in parallel using Pool
            with Pool() as pool:

                sampler = emcee.EnsembleSampler(nwalkers, ndim, log_probability, args=(ts_ecl, theta_xs_rec, theta_ys_rec, RA_errs_ecl, DEC_errs_ecl, delta_gamma, use_JWST, x_tele, y_tele, z_tele), pool = pool)
                
                sampler.run_mcmc(pos, nsteps, progress = True)
            
            if make_convergence_plots:
            
                # turn this on to show the chains
                fig, axes = plt.subplots(6, figsize=(5., 3.5), sharex=True)
                samples = sampler.get_chain()

                for i in range(ndim):
                    ax = axes[i]
                    ax.plot(samples[:, :, i], "k", alpha=0.3)
                    ax.set_xlim(0, len(samples))
                    ax.set_ylabel(abg_labels[i])
                    ax.yaxis.set_label_coords(-0.1, 0.5)
                    plt.yscale('symlog')

                axes[-1].set_xlabel("step number")
                plt.tight_layout()
                plt.savefig(os.path.join('MCMC_grid_data', 'convergence_tests', grid_key + 'abg_convergences_' + '' + JWST_str + '.png'))
                plt.close('all')
            
            '''
            # if the there is a non-nan autocorr time, we can compute burn-in and thin automatically..
            if not math.isnan(np.nanmax(tau)):

                # emcee recommends the burn-in parameter to be a few timnes the max-autocorrelation time
                burnin_number = int(np.ceil(np.nanmax(tau) * 3.)) # to get as high as possible

                # emcee recommends the thin to be ~half of the max autocorrelation time
                thin_number = int(np.ceil(np.nanmin(tau) / 2.)) # to get as low as possible

            # ..otherwise, these values will suffice
            else:
            
                burnin_number, thin_number = 1000, 150
            
            '''
            
            burnin_number, thin_number = 1000, 50
            
            # get our flat samples
            flat_samples = sampler.get_chain(discard = burnin_number, thin = thin_number, flat = True)
            
            # get the 16th, 50th, and 84th percentile solutions to our MCMC per parameter
            param = []
            for i in range(len(abg_labels)):

                param.append(np.percentile(flat_samples[:, i], [50.0])[0])
            
            # we can safely break our 3 chi squareds up
            cs1, cs2, cs3 = np.array(log_likelihood2(param, ts_ecl, theta_xs_rec, theta_ys_rec, RA_errs_ecl, DEC_errs_ecl, delta_gamma, use_JWST, x_tele, y_tele, z_tele))
            
            if make_corner_plots:
            
                fig = corner.corner(
                flat_samples, labels=abg_labels, truths = true_elements)
                
                inds = np.random.randint(len(flat_samples), size = 1000) # show me a few ( in this case 1000 ) samples of the chain

                for ind in inds:

                    sample = flat_samples[ind]
                    plt.plot(ts_ecl, np.dot(np.vander(ts_ecl, len(abg_labels)), sample[:len(abg_labels)]), "C1", alpha=0.1)
                    lims = np.percentile(sample[:len(abg_labels)], [15.9, 50, 84.1])

                plt.legend(fontsize=14)
                plt.xlabel("x")
                plt.ylabel("y");
                plt.title('arc=' + arc_length + ', ' + str(num_epochs) + 'obs')
                plt.savefig(os.path.join('MCMC_grid_data', 'corner_plots', 'abg_posteriors_' + grid_key + '' + JWST_str + '.png'), dpi = 500)
                plt.close('all')

            # extract alpha, beta, gamma, etc from our flat_samples
            alpha_samples = flat_samples[:,0]
            adot_samples  = flat_samples[:,1]
            beta_samples  = flat_samples[:,2]
            bdot_samples  = flat_samples[:,3]
            gamma_samples = flat_samples[:,4]
            gdot_samples  = flat_samples[:,5]

            # convert alpaha, beta, gama, etc to cartesian
            x_samples = alpha_samples / gamma_samples
            y_samples = beta_samples / gamma_samples
            z_samples = 1. / gamma_samples
            vx_samples = adot_samples / gamma_samples
            vy_samples = bdot_samples / gamma_samples
            vz_samples = gdot_samples / gamma_samples

            # we MUST rotate backwards to go from telescopecentric- to barycentric-frame, so we can convert into orbital elements
            x_samples, y_samples, z_samples = rotate_coordinates(x_samples, y_samples, z_samples, l0, b0, reverse = True)
            vx_samples, vy_samples, vz_samples = rotate_coordinates(vx_samples, vy_samples, vz_samples, l0, b0, reverse = True)
            
            # after rotating, we must add back in the origin of our observatory's ecliptic coordinates
            x_samples += xs_ecl[0]
            y_samples += ys_ecl[0]
            z_samples += zs_ecl[0]

            # now that we're in barycentric cartesian, we can convert to orbital parameters!
            a_list, e_list, i_list, w_list, W_list = [], [], [], [], []
            
            # this looks like a time consuming loop, but it actually takes less than 1 second
            for j in range(len(x_samples)):

                a, e, i, w, W, nu, M, E, Tp = get_orbital_from_cartesian([ x_samples[j],  y_samples[j],  z_samples[j]],
                                                                         [vx_samples[j], vy_samples[j], vz_samples[j]], mu = mu)
                                                                  
                a_list.append(a)
                e_list.append(e)
                i_list.append(i)
                w_list.append(w)
                W_list.append(W)
                
            a_list = np.array(a_list)
            e_list = np.array(e_list)
            q_list = a_list * (1 - e_list)
            i_list = np.array(i_list)
            w_list = np.array(w_list)
            W_list = np.array(W_list)
                    
            # generate what a `flat_samples` would look like if we had sapmled entirely in aei-space
            flat_samples = np.array([a_list, e_list, q_list, i_list, w_list, W_list])
            flat_samples = np.array(flat_samples.T)
            
            if make_corner_plots:
            
                fig, axes = plt.subplots(6, figsize=(10, 7), sharex=True)
                samples = sampler.get_chain()

                fig = corner.corner(
                flat_samples, labels=aei_labels, truths = true_elements)
                
                inds = np.random.randint(len(flat_samples), size = 1000) # show me a few ( in this case 1000 ) samples of the chain

                for ind in inds:

                    sample = flat_samples[ind]
                    plt.plot(ts_ecl, np.dot(np.vander(ts_ecl, len(aei_labels)), sample[:len(aei_labels)]), "C1", alpha=0.1)
                    lims = np.percentile(sample[:len(aei_labels)], [15.9, 50, 84.1])

                plt.legend(fontsize=14)
                plt.xlabel("x")
                plt.ylabel("y");
                plt.title('arc=' + arc_length + ', ' + str(num_epochs) + 'obs')
                plt.savefig(os.path.join('MCMC_grid_data', 'corner_plots', 'aei_posteriors_' + grid_key + '' + JWST_str + '.png'), dpi = 500)
                plt.close('all')

            # supply the units our [a, e, q, i, w, W] will be in
            units = ['AU', '', 'AU', 'rad', 'rad', 'rad']

            # this list will be for holding our sigma_X / X values
            sigma_overs = []
            
            # open a list to store the recovered orbital elements for future comparison
            param_rec = []

            # get the 16th, 50th, and 84th percentile solutions to our MCMC per parameter
            for i in range(len(aei_labels)):

                unit = units[i]

                mcmc = np.percentile(flat_samples[:, i], [15.9, 50, 84.1])
                q = np.diff(mcmc)
                txt = "\mathrm{{{3}}} = {0:.6f}_{{-{1:.9f}}}^{{{2:.9f}}}"
                txt = txt.format(mcmc[1], q[0], q[1], aei_labels[i])
                param_rec.append(mcmc[1])
                if write_posteriors_separately: results_file.write((txt + ' (true=' + str(true_elements[i]) + ' ' + unit + ')\n').encode())
                
                # we only care about appending a, e, and q
                if i <= 2:
                    
                    sigma_over = ((q[1] + q[0]) / 2.) / mcmc[1]
                    sigma_overs.append(sigma_over)
                
                # only want to write to file if our MCMC has converged
                if i == 2:
                    
                    perihelion_datafile.write(OSSOS_object + ' ' + str(arc_length) + ' ' + str(epoch).zfill(3) + ' ' + str(len(ts_ecl)).zfill(3) + ' ' + str(sigma_overs[0]) + ' ' + str(sigma_overs[1]) + ' ' + str(sigma_overs[2]) + ' ' + str(true_elements)[1:-1].replace(',', '') + ' ' + str(cs1) + ' ' + str(cs2) + ' ' + str(cs3) + ' ' + str(cs1 + cs2 + cs3) + ' ' + str(param_rec)[1:-1].replace(',', '') + '\n')
                    perihelion_datafile.flush()
