import numpy as np
from scipy.special import jn
import time
# maybe one day turn this into a class for orbital solutions? but not today
#class orbital_solution():


#def __init__(self):
    
#        return self

def cartesian_to_keplerian(cartesian, epoch, helio = False, ecliptic = False):
    '''
    Goes from ecliptic or equatorially oriented state vector (i.e. cartesian representation) to orbital elements.

    Args:
        cartesian (n x 6 array): array with the (x,y,z,vx,vy,vz) Cartesian elements
        epoch (float): Epoch at which the elements are defined, in years
        helio (bool, default = False): Switches between barycentric and heliocentric elements (False is barycentric)
        ecliptic (bool, default = False): Use true if input elements are equatorially-aligned (ICRS)
    Returns:
        aei (n x 6 array): array with (a,e,i,Omega,omega,T_p) elements
    '''
    mu = SunGM if helio else SolarSystemGM

    xv = np.zeros_like(cartesian)
    if not ecliptic:
        cosEcl = np.cos(EclipticInclination)
        sinEcl = np.sin(EclipticInclination)
        xv[:,0] = cartesian[:,0]
        xv[:,3] = cartesian[:,3]
        xv[:,1], xv[:,2] = cosEcl * cartesian[:,1] + sinEcl * cartesian[:,2], -sinEcl * cartesian[:,1] + cosEcl * cartesian[:,2]
        xv[:,4], xv[:,5] = cosEcl * cartesian[:,4] + sinEcl * cartesian[:,5], -sinEcl * cartesian[:,4] + cosEcl * cartesian[:,5]
    else:
        xv = cartesian


    x = np.sqrt(xv[:,0]*xv[:,0] + xv[:,1]*xv[:,1]+ xv[:,2]*xv[:,2])
    vsq_mu = (xv[:,3]**2 + xv[:,4]**2 + xv[:,5]**2)/mu

    inv_a = 2./x - vsq_mu
    a = 1./inv_a

    x_dot_v = (xv[:,0] * xv[:,3] + xv[:,1] * xv[:,4] + xv[:,2] * xv[:,5])
    pref = (vsq_mu - 1./x)
    e_vec = (pref * xv[:,0:3].T -  x_dot_v * xv[:,3:6].T/mu).T
    e = np.sqrt(e_vec[:,0] * e_vec[:,0] + e_vec[:,1] * e_vec[:,1] + e_vec[:,2] * e_vec[:,2])
    h_vec = np.cross(xv[:,0:3], xv[:,3:6])
    n_vec = np.cross(np.array([0,0,1]), h_vec)
    h = np.sqrt(h_vec[:,0] * h_vec[:,0] + h_vec[:,1] * h_vec[:,1] + h_vec[:,2] * h_vec[:,2])
    n = np.sqrt(n_vec[:,0] * n_vec[:,0] + n_vec[:,1] * n_vec[:,1] + n_vec[:,2] * n_vec[:,2])
    cos_i = h_vec[:,2]/h

    cosOmega = n_vec[:,0]/n
    cosomega = (n_vec[:,0] * e_vec[:,0] + n_vec[:,1] * e_vec[:,1] + n_vec[:,2] * e_vec[:,2])/(n*e)

    i = np.arccos(cos_i) * 180./np.pi
    Omega = np.arccos(cosOmega) * 180./np.pi
    omega = np.arccos(cosomega) * 180./np.pi
    Omega[np.where(n_vec[:,1] < 0)] = 360 - Omega[np.where(n_vec[:,1] < 0)]
    omega[np.where(e_vec[:,2] < 0)] = 360 - omega[np.where(e_vec[:,2] < 0)]

    p = h*h/mu
    b = a * np.sqrt(1 - e*e)

    xbar = (p - x)/e
    ybar = x_dot_v/e * np.sqrt(p/mu)

    E = np.arctan2(ybar/b, xbar/a + e)

    M = E - e*np.sin(E)

    T_p = epoch - M * np.sqrt(a**3/mu)

    aei = np.zeros_like(xv)

    aei[:,0] = a
    aei[:,1] = e
    aei[:,2] = i
    aei[:,3] = Omega
    aei[:,4] = omega
    aei[:,5] = T_p

    return aei
    
    '''
    Args:
        cartesian (n x 6 array): array with the (x,y,z,vx,vy,vz) Cartesian elements
        epoch (float): Epoch at which the elements are defined, in years
        helio (bool, default = False): Switches between barycentric and heliocentric elements (False is barycentric)
        ecliptic (bool, default = False): Use true if input elements are equatorially-aligned (ICRS)
    Returns:
        aei (n x 6 array): array with (a,e,i,Omega,omega,T_p) elements
    '''
    mu = SunGM if helio else SolarSystemGM
    xv = np.zeros_like(cartesian)
    if not ecliptic:
        cosEcl = np.cos(EclipticInclination)
        sinEcl = np.sin(EclipticInclination)
        xv[:,0] = cartesian[:,0]
        xv[:,3] = cartesian[:,3]
        xv[:,1], xv[:,2] = cosEcl * cartesian[:,1] + sinEcl * cartesian[:,2], -sinEcl * cartesian[:,1] + cosEcl * cartesian[:,2]
        xv[:,4], xv[:,5] = cosEcl * cartesian[:,4] + sinEcl * cartesian[:,5], -sinEcl * cartesian[:,4] + cosEcl * cartesian[:,5]
    else:
        xv = cartesian

    x = np.sqrt(xv[:,0]*xv[:,0] + xv[:,1]*xv[:,1]+ xv[:,2]*xv[:,2])
    vsq_mu = (xv[:,3]**2 + xv[:,4]**2 + xv[:,5]**2)/mu
    inv_a = 2./x - vsq_mu
    a = 1./inv_a
    x_dot_v = (xv[:,0] * xv[:,3] + xv[:,1] * xv[:,4] + xv[:,2] * xv[:,5])
    pref = (vsq_mu - 1./x)
    e_vec = (pref * xv[:,0:3].T -  x_dot_v * xv[:,3:6].T/mu).T
    e = np.sqrt(e_vec[:,0] * e_vec[:,0] + e_vec[:,1] * e_vec[:,1] + e_vec[:,2] * e_vec[:,2])
    h_vec = np.cross(xv[:,0:3], xv[:,3:6])
    n_vec = np.cross(np.array([0,0,1]), h_vec)
    h = np.sqrt(h_vec[:,0] * h_vec[:,0] + h_vec[:,1] * h_vec[:,1] + h_vec[:,2] * h_vec[:,2])
    n = np.sqrt(n_vec[:,0] * n_vec[:,0] + n_vec[:,1] * n_vec[:,1] + n_vec[:,2] * n_vec[:,2])
    cos_i = h_vec[:,2]/h
    cosOmega = n_vec[:,0]/n
    cosomega = (n_vec[:,0] * e_vec[:,0] + n_vec[:,1] * e_vec[:,1] + n_vec[:,2] * e_vec[:,2])/(n*e)
    i = np.arccos(cos_i) * 180./np.pi
    Omega = np.arccos(cosOmega) * 180./np.pi
    omega = np.arccos(cosomega) * 180./np.pi
    Omega[np.where(n_vec[:,1] < 0)] = 360 - Omega[np.where(n_vec[:,1] < 0)]
    omega[np.where(e_vec[:,2] < 0)] = 360 - omega[np.where(e_vec[:,2] < 0)]
    p = h*h/mu
    b = a * np.sqrt(1 - e*e)
    xbar = (p - x)/e
    ybar = x_dot_v/e * np.sqrt(p/mu)
    E = np.arctan2(ybar/b, xbar/a + e)
    M = E - e*np.sin(E)
    T_p = epoch - M * np.sqrt(a**3/mu)
    aei = np.zeros_like(xv)
    aei[:,0] = a
    aei[:,1] = e
    aei[:,2] = i
    aei[:,3] = Omega
    aei[:,4] = omega
    aei[:,5] = T_p
    return aei

        
def get_orbital_from_cartesian(r_vec, v_vec, mu = 6.67408e-11 * 1.9891e30):
    
    # it will be helpful to have these norms ahead of time
    r = np.sqrt(np.dot(r_vec, r_vec))
    v = np.sqrt(np.dot(v_vec, v_vec))
    
    # compute semi major axis
    a = 1. / (2. / r - np.dot(v_vec, v_vec) / mu)
    
    # first, we must compute the angular momentum vector
    h_vec = np.cross(r_vec, v_vec)
    h = np.sqrt(np.dot(h_vec, h_vec)) # get the norm while we're at it
    
    # now we have enough to compute the eccentricity vector and its mag
    e_vec = np.cross(v_vec, h_vec) / mu - r_vec / r
    e = np.sqrt(np.dot(e_vec, e_vec))
    
    # determine inclination [rad]
    i = np.arccos(h_vec[2] / h)
    
    # can compute the true anomaly [rad], and modulate if necessary
    if True:#e < 1:
        nu = np.arccos(np.dot(e_vec, r_vec) / (e * r))
        if np.dot(r_vec, v_vec) < 0.: nu = 2 * np.pi - nu
    else:
        nu = None
    
    # compute the eccentric anomaly
    if True:#e < 1:
        E = 2 * np.arctan2(np.tan(nu / 2.), np.sqrt((1 + e) / (1 - e)))
    else: E = None
    
    # comoute the vector which points towards the ascending node
    n_vec = np.cross(np.array([0., 0., 1.]), h_vec)
    n = np.sqrt(np.dot(n_vec, n_vec))
    
    # compute the longitude of the ascending node
    W = np.arccos(n_vec[0] / n)
    if n_vec[1] < 0.: W = 2 * np.pi - W # modulo if it's not between 0 and 2pi
    
    # compute the argument of periastron
    if True:#e < 1:
        if e_vec[2] >= 0.:
            w = np.arccos(np.dot(n_vec, e_vec) / (n * e))
        else: w = 2 * np.pi - np.arccos(np.dot(n_vec, e_vec) / (n * e))
        
    else: w = None
    
    # compute mean anomaly
    if True:#e < 1:
        M = E - e * np.sin(E)
    else: M = None
    
    # compute time of periastron passage
    if True:#a > 0:
        Tp = -np.sqrt(a**3 / mu) * M
    else: Tp = None
    
    '''
    https://www.narom.no/undervisningsressurser/sarepta/rocket-theory/satellite-orbits/introduction-of-the-six-basic-parameters-describing-satellite-orbits/
    '''
    '''
    #e = np.sqrt(1 - (h**2) / (a * mu))
    #print(e)
    #print('done that')
    
    #7
    omega_LAN = np.arctan2(h_bar[0], -h_bar[1])
    #8
    #beware of division by zero here
    lat = np.arctan2(np.divide(r_vec[2],(np.sin(i))),\
    (r_vec[0] * np.cos(omega_LAN) + r_vec[1] * np.sin(omega_LAN)))
    #9
    p = a * (1 - e**2)
    print(e)
    nu = np.arctan2(np.sqrt(p / mu) * np.dot(r_vec, v_vec), p - r)
    #10
    omega_AP = lat - nu
    #11
    EA = 2 * np.arctan2((1 - e)**0.5 * np.sin(nu / 2.), (1 + e)**0.5 * np.cos(nu / 2.))
    #12
    n = np.sqrt(mu / (a**3))
    T = -(1/n)*(EA - e*np.sin(EA))
    '''
    
    return a, e, i, w, W, nu, M, E, Tp
    
def get_true_anomaly_from_mean_anomaly(M, e, n_s, n_p):
 
    N = 100
    '''
    Es = []
    
    for m in M:
     
        if m == 0.: E = 0
        
        else:
        
            E = m
        
            for n in range(N):
            
                E = E - (E - e * np.sin(E) - m) / (1. - e * np.cos(E))
                
        Es.append(E)
        
    Es = np.array(Es)
        
    #nus = np.arccos((np.cos(Es) - e) / (1 - e * np.cos(Es)))
    nus = 2 * np.arctan(np.sqrt((1 + e) / (1 - e)) * np.tan(Es / 2))
    nus = np.arctan2(np.cos(Es) - e, np.sqrt(1 - e**2) * np.sin(Es))
    '''

    # same thing but apparently the list comprehnsion version is a little bit smaller
    #Es = np.array([m + np.sum([2. / k * jn(k, k * e) * np.sin(k * m) for k in np.arange(N) + 1]) for m in M])
    
    Es = []
    # M is an array of mean anomaly values -- must convert to according array of Es
    for m in M:
    
        E0 = m
        E1 = 0
    
        for k in np.arange(N) + 1:
        
            E1 += 2. / k * jn(k, k * e) * np.sin(k * m)
            
        Es.append(E0 + E1)
        
    E = np.array(Es)

    #nu = 2 * np.arctan2(np.cos(E) - e, np.sqrt(1 - e**2) * np.sin(E))
    nu = 2 * np.arctan2((1. + e)**0.5 * np.sin(E / 2.), (1. - e)**0.5 * np.cos(E / 2.))
 
    '''
    beta = np.sqrt(1 - e**2) / e
    print M
    
    nus = []
    
    for m in M:
    
        s_list = []
    
        for s in (np.arange(n_s) + 1):
    
            p_sum = np.sum([beta**p * (jn(s - p, s * e) + jn(s + p, s * e)) for p in (np.arange(n_p) + 1)])
        
            s_list.append(1. / s * (jn(s, s * e) + p_sum) * np.sin(s * m))
            
        s_sum = np.sum(s_list)
            
        nus.append(m + 2 * s_sum)
    '''
    #import matplotlib.pyplot as plt
    #plt.plot(nus)
    #plt.show()
    #print np.sum([1. / s * (jn(s, s * e) + np.sum([(1. / e * np.sqrt(1 - e**2))**p * (jn(s - p, s * e) + jn(s + p, s * e)) for p in (np.arange(n_p) + 1)])) * np.sin(s * M) for s in (np.arange(n_s) + 1)])
    #print np.sum([(1. / e * np.sqrt(1 - e**2))**p * (jn(s - p, s * e) + jn(s + p, s * e)) for p in (np.arange(n_p) + 1)])
    #return M + 2 * np.sum([1. / s * (jn(s, s * e) + np.sum([(1. / e * np.sqrt(1 - e**2))**p * (jn(s - p, s * e) + jn(s + p, s * e)) for p in (np.arange(n_p) + 1)])) * np.sin(s * M) for s in (np.arange(n_s) + 1)])
    
    return np.array(nu)

def get_cartesian_from_orbital(a, e, i, omega_LAN, omega_AP, t, t0 = 0., mu = 6.67408e-11 * 1.9891e30):
    
    n = np.sqrt(mu / (a**3))
          
    # rename some orbital angles for succinctness
    h = np.sqrt(mu * a * (1 - e**2))
    p = a *(1 - e**2)
    Om = omega_LAN
    w = omega_AP
    n_s = 100
    # use the mean anomaly, f, to define our true anomaly
    f = n * (t - t0)
    #if e==0.: nu = np.zeros_like(t)
    nu = get_true_anomaly_from_mean_anomaly(f, e, n_s = n_s, n_p = n_s)

    r = a * (1 - e**2) / (1 + e * np.cos(nu))

    x = r * (np.cos(Om) * np.cos(w + nu) - np.sin(Om) * np.sin(w + nu)*np.cos(i))
    y = r * (np.sin(Om) * np.cos(w + nu) + np.cos(Om) * np.sin(w + nu)*np.cos(i))
    z = r * (np.sin(i) * np.sin(w + nu))

    vx = (x*h*e/(r*p))*np.sin(nu) - (h/r)*(np.cos(Om)*np.sin(w+nu) + np.sin(Om)*np.cos(w+nu)*np.cos(i))
    vy = (y*h*e/(r*p))*np.sin(nu) - (h/r)*(np.sin(Om)*np.sin(w+nu) - np.cos(Om)*np.cos(w+nu)*np.cos(i))
    vz = (z*h*e/(r*p))*np.sin(nu) - (h/r)*(np.cos(w+nu)*np.sin(i))

    return np.array([x, y, z]), np.array([vx, vy, vz])
'''
G= 6.673e-11 # grav constant
Msun = 1.989e30 # kg
mu = G * Msun

# For KBO
a = 40*1.496e11#449.30762619559084 * 1.496e11 # AU
e = 0.2#0.9215520598744223
i = 10 * np.pi / 180. #54.110668163690505 * np.pi / 180. # degrees
omega_AP = np.pi / 3 #348.05982971243543 * np.pi / 180. #np.pi - 1
omega_LAN = np.pi / 6 #135.21320372655646 * np.pi / 180. #110.30347 * np.pi / 180.
T = np.sqrt(4 * np.pi**2 * a**3 / (G * Msun))

# -----------------------------
# now we may begin the program!
# -----------------------------
t0 = 0. # should this be J2000

ts = np.linspace(t0, T, 10000)
 
q=time.time()

rs = [get_cartesian_from_orbital(a, e, i, omega_LAN, omega_AP, t) for t in ts]

print time.time()-q
print np.sum(rs)
'''
