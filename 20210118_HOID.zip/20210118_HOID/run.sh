#!/bin/bash

declare -a Nobs=("0305" "1030")

for N in "${Nobs[@]}"; do
    cd $N
    python3 "analysis.py" &
    cd ".."
done

