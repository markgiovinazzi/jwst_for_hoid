#!/bin/bash

declare -a Nobs=("03" "05" "10" "30")
declare -a whichbatch=("1st" "2nd")

for N in "${Nobs[@]}"; do
    for which in "${whichbatch[@]}"; do
        cd $N"_"$which"half"
        python3 "analysis.py" &
        cd ".."
    done
done

