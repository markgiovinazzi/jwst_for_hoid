import numpy as np

# get (RA, DEC) from (l, b)
def get_RADEC_from_lb(l, b, epsilon = 23.43928 * np.pi / 180.):

    RA = np.arctan2((np.cos(epsilon) * np.cos(b) * np.sin(l) - np.sin(epsilon) * np.sin(b)), (np.cos(b) * np.cos(l)))
    DEC = np.arcsin(np.cos(epsilon) * np.sin(b) + np.sin(epsilon) * np.cos(b) * np.sin(l))

    return RA, DEC

# get (l, b) from (RA, DEC)
def get_lb_from_RADEC(RA, DEC, epsilon = 23.43928 * np.pi / 180.):

    l = np.arctan2((np.cos(epsilon) * np.cos(DEC) * np.sin(RA) + np.sin(epsilon) * np.sin(DEC)), (np.cos(DEC) * np.cos(RA)))
    b = np.arcsin(np.cos(epsilon) * np.sin(DEC) - np.sin(epsilon) * np.cos(DEC) * np.sin(RA))

    return l, b

# get (l, b) from (theta_xs, theta_ys)
def get_lb_from_thetas(theta_xs, theta_ys, l0, b0):

    #l = np.arcsin(theta_xs / np.cos(b0) / np.sqrt(1 + theta_xs**2 + theta_ys**2)) + l0
    #b = np.arcsin((np.sin(b0) + theta_ys * np.cos(b0)) / np.sqrt(1 + theta_xs**2 + theta_ys**2))
    
    rho = np.sqrt(theta_xs**2 + theta_ys**2)
    c = np.arctan(rho)

    l = l0 + np.arctan2(theta_xs * np.sin(c), (rho * np.cos(b0) * np.cos(c) - theta_ys * np.sin(b0) * np.sin(c)))
    b = np.arcsin(np.cos(c) * np.sin(b0) + theta_ys * np.sin(c) * np.cos(b0) / rho)

    return l, b

# get (theta_xs, theta_ys) from (l, b)
def get_thetas_from_lb(l, b, l0, b0):

    denominator = np.sin(b0) * np.sin(b) + np.cos(b0) * np.cos(b) * np.cos(l - l0)

    theta_xs = np.cos(b) * np.sin(l - l0) / denominator
    theta_ys = (np.cos(b0) * np.sin(b) - np.sin(b0) * np.cos(b) * np.cos(l - l0)) / denominator
    
    return theta_xs, theta_ys

# get thetas from positions on KBO and given observatory
def get_thetas_from_cartesian(r_object, r_observatory):

    theta_xs = (r_object[0] - r_observatory[0]) / (r_object[2] - r_observatory[2])
    theta_ys = (r_object[1] - r_observatory[1]) / (r_object[2] - r_observatory[2])

    return theta_xs, theta_ys
    
# get positions on KBO and given observatory from thetas
def get_cartesian_from_thetas(theta_xs_obs1, theta_xs_obs2, theta_ys_obs1, theta_ys_obs2, r_obs1, r_obs2):

    # define short-hand variables to make our below equations easier
    a = theta_xs_obs1
    b = r_obs1[0]
    c = r_obs1[2]
    d = theta_ys_obs1
    f = r_obs1[1]
    g = theta_xs_obs2
    h = r_obs2[0]
    j = r_obs2[2]
    k = theta_ys_obs2
    l = r_obs2[1]

    xs = (a * (c * g - g * j + h) - b * g) / (a - g)
    ys = (a * f - b * d + c * d * g - d * g * j + d * h - f * g) / (a - g)
    zs = (a * c - b - g * j + h) / (a - g)

    return np.array([xs, ys, zs])

# The following function reparamaterizes a cartesian phasespace into Gary's notation
def cartesian_to_telescopecentric(rvec, vvec):

    x, y, z = rvec
    vx, vy, vz = vvec

    alpha, beta, gamma = x / z, y / z, 1. / z
    adot, bdot, gdot = vx / z, vy / z, vz / z

    return alpha, beta, gamma, adot, bdot, gdot
    
# function fo go from alpha, beta, gamma =-> xyz
def telescopecentric_to_cartesian(alpha, beta, gamma, adot, bdot, gdot):

    # note the `1.` here is in units of AU -- be careful!
    x, y, z = alpha / gamma, beta / gamma, 1. / gamma
    vx, vy, vz = adot / gamma, bdot / gamma, gdot / gamma
    
    return x, y, z, vx, vy, vz

# The following function converts alpha, beta, gamma into thetas
def telescopecentric_to_thetas(alpha, beta, gamma, r_obs):

     # note the `1.` here is in units of AU -- be careful!
    x, y, z = alpha / gamma, beta / gamma, 1. / gamma
   
    theta_x = (x - r_obs[0]) / (z - r_obs[2])
    theta_y = (y - r_obs[1]) / (z - r_obs[2])

    return theta_x, theta_y
    
# convert thetas into an observed alpha, beta, gamma, adot, bdot, gdot; includes parallax computation
def thetas_to_telescopecentric(tx_J, ty_J, tx_g, ty_g, r_JWST, r_gbt):

    # first we must compute gamma; we may do so from our theta_x or theta_y measurements
    gamma_x = (tx_g - tx_J) / (tx_g * r_gbt[2] - tx_J * r_JWST[2] + r_JWST[0] - r_gbt[0])
    gamma_y = (ty_g - ty_J) / (ty_g * r_gbt[2] - ty_J * r_JWST[2] + r_JWST[1] - r_gbt[1])
    
    # average the two to be safe (though in principle they should be the same)
    gamma = (gamma_x + gamma_y) / 2.
    
    # now we can get alpha and beta
    alpha = gamma * (tx_g * tx_J * r_JWST[1] - tx_J * tx_g * r_gbt[1] + tx_J * r_gbt[0] * ty_g - r_JWST[0] * ty_J * tx_g) / (ty_g * tx_J - tx_g * ty_J)
    beta =  gamma * (ty_g * tx_J * r_JWST[1] - ty_g * ty_J * r_JWST[0] + ty_J * r_gbt[0] * ty_g - r_gbt[1] * ty_J * tx_g) / (ty_g * tx_J - tx_g * ty_J)
    
    return alpha, beta, gamma
