import numpy as np
from astrometric_conversions import *

# transform from one coordinate system to another
def coordinate_transformation(old_pos, r0_prime):

    new_pos = old_pos - r0_prime
    
    return new_pos

# rotates coordinates such that x-hat points JWST->obs, z-hat perpindicular in plane of Solar System
def apply_rotation_matrix(r, x_hat, y_hat):

    new_x = r[0] * x_hat[0] + r[1] * x_hat[1] + r[2] * x_hat[2]
    new_y = r[2]
    new_z = r[0] * y_hat[0] + r[1] * y_hat[1] + r[2] * y_hat[2]

    # it is important now to flip the y- and z-axes
    return np.array([new_x, new_y, new_z])
    
# rotates coordinates back, though we can leave the convention of xz being in the plane
def reverse_rotation_matrix(r, x_hat, y_hat):

    new_x = r[0] * x_hat[0] + r[1] * x_hat[1] + r[2] * x_hat[2]
    new_y = r[0] * y_hat[0] + r[1] * y_hat[1] + r[2] * y_hat[2]
    new_z = r[1]

    # it is important now to flip the y- and z-axes
    return np.array([new_x, new_y, new_z])

# convert customized positions and move them to our new coordinate system, returning observed RAs/DECs
def transform_position(r_obj, r_gbt, r_JWST, shift = True):

    # there may be cases where we want our transformation to exclude the shift, like for a unit vector
    if shift:
        
        # the following factor is necessary to apply our coordinate transformation
        r0_prime = np.array([[q[0]] for q in (r_gbt + r_JWST) / 2.])

        # provide the old positions in our new coordinate frame
        r_obj_prime  = coordinate_transformation(r_obj,  r0_prime)
        r_gbt_prime  = coordinate_transformation(r_gbt,  r0_prime)
        r_JWST_prime = coordinate_transformation(r_JWST, r0_prime)
        
    else:
    
        r_obj_prime = r_obj
        r_gbt_prime = r_gbt
        r_JWST_prime = r_JWST

    # first, define the unit vector which will help define our rotation
    x = np.array([q[0] for q in r_gbt_prime - r_JWST_prime]).reshape(3, 1)
    x_hat = x / np.sqrt(x[0]**2 + x[1]**2 + x[2]**2)
    y_hat = np.array([-x_hat[1], x_hat[0], x_hat[2]])
    
    # apply the rotation
    r_obj_prime = apply_rotation_matrix(r_obj_prime, x_hat, y_hat)
    
    # and return them, as well as the distances because we may need them
    return r_obj_prime
    
# convert customized positions and move them to our new coordinate system, returning observed RAs/DECs
def convert_positions_to_RADEC(r_KBO, r_obs, r_JWST, l0_JWST = 0., b0_JWST = 0., l0_obs = 0., b0_obs = 0.):

    # get measured thetas of our KBO on behalf of both JWST and obs
    theta_xs_JWST, theta_ys_JWST = get_thetas_from_cartesian(r_KBO, r_JWST)
    theta_xs_obs, theta_ys_obs = get_thetas_from_cartesian(r_KBO, r_obs)

    # convert thetas to (l, b) as intermediate step in computing RAs/DECs
    ls_JWST, bs_JWST = get_lb_from_thetas(theta_xs_JWST, theta_ys_JWST, l0 = l0_JWST, b0 = b0_JWST)
    ls_obs, bs_obs = get_lb_from_thetas(theta_xs_obs, theta_ys_obs, l0 = l0_obs, b0 = b0_obs)

    # use these (l, b) to produce our observed RAs/DECs
    RA_JWST, DEC_JWST = get_RADEC_from_lb(ls_JWST, bs_JWST)
    RA_obs, DEC_obs = get_RADEC_from_lb(ls_obs, bs_obs)
    
    # and return them, as well as the distances because we may need them
    return RA_JWST, DEC_JWST, RA_obs, DEC_obs

# create a function which will apply some error to our simulated RA/DEC observations
def add_measurement_noise(RA, DEC, error, average = 0, exact_error = False):

    if exact_error:
    
        RA = np.array([RA[i] + error for i in range(len(RA))])
        DEC = np.array([DEC[i] + error for i in range(len(DEC))])
    
    else:

        RA = np.array([RA[i] + np.random.normal(average, error) for i in range(len(RA))])
        DEC = np.array([DEC[i] + np.random.normal(average, error) for i in range(len(DEC))])

    return RA, DEC
    
def convert_RADEC_to_positions(RA_JWST, DEC_JWST, RA_obs, DEC_obs, r_obs_prime, r_JWST_prime, l0_JWST = 0., b0_JWST = 0., l0_obs = 0., b0_obs = 0.):

    ls_JWST, bs_JWST = get_lb_from_RADEC(RA_JWST, DEC_JWST)
    ls_obs, bs_obs = get_lb_from_RADEC(RA_obs, DEC_obs)
    
    theta_xs_JWST, theta_ys_JWST = get_thetas_from_lb(ls_JWST, bs_JWST, l0_JWST, b0_JWST)
    theta_xs_obs, theta_ys_obs = get_thetas_from_lb(ls_obs, bs_obs, l0_obs, b0_obs)

    r_KBO_recovered = get_cartesian_from_thetas(theta_xs_obs, theta_xs_JWST, theta_ys_obs, theta_ys_JWST, r_obs_prime, r_JWST_prime)
    
    return r_KBO_recovered

# ultimately, r_sun to be replaced with r_bary
def convert_to_barycentric_frame(r_obj, r_sun, x_hat, y_hat):

    # apply the rotation
    r_obj = reverse_rotation_matrix(r_obj, x_hat, y_hat)

    # the following factor is necessary to apply our coordinate transformation
    r_sun = reverse_rotation_matrix(r_sun, x_hat, y_hat)

    # provide the old positions in our new coordinate frame
    r_obj -= r_sun
    
    return r_obj

