#!/bin/bash

declare -a Nobs=("03" "05" "10" "30")

for N in "${Nobs[@]}"; do
    cd $N
    python3 "analysis.py" &
    cd ".."
done

