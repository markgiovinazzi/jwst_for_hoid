# convert from radians to arseconds
def rad_to_arcsec(rad):

    arcsec = rad * 206265
    
    return arcsec
    
# convert from arcseconds to radians
def arcsec_to_rad(arcsec):

    rad = arcsec / 206265.
    
    return rad
    
# convert milliarcseconds to radians
def mas_to_rad(mas):

    rad = mas / 206265. / 1000.
    
    return rad
    
# convert from meters to AU
def m_to_AU(m):

    AU = m * 6.6845871226706e-12
    
    return AU
    
# convert from AU to meters
def AU_to_m(AU):

    m = AU * 1.49597870691e11
    
    return m
 
# convert from AU to pc
def AU_to_pc(AU):

    pc = AU * 4.84814e-6

    return pc
    
# convert from kilometers to meters
def km_to_m(km):

    m = km * 1000
        
    return m

def s_to_yr(s):

    yr = s / 3600. / 24. / 365.25
    
    return yr
