import matplotlib.pyplot as plt
import numpy as np
from astropy.io import ascii
from functools import reduce

file_name = 'perihelion_data.txt'

f = open(file_name, 'r')

lines = f.readlines()

objs, arcs, epochs, obss, sigma_as, sigma_es, sigma_qs, a_trues, e_trues, q_trues, i_trues, w_trues, W_trues, a_recs, e_recs, q_recs, css, z_guesses, z_trues, dofs = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []

for line in lines[1:]:

    objs.append(line.split()[0])
    arcs.append(float(line.split()[1][:-2]))
    epochs.append(int(line.split()[2][-2:]))
    obss.append(int(line.split()[3][-2:]))
    sigma_as.append(float(line.split()[4]))
    sigma_es.append(float(line.split()[5]))
    sigma_qs.append(float(line.split()[6]))
    a_trues.append(float(line.split()[7]))
    e_trues.append(float(line.split()[8]))
    q_trues.append(float(line.split()[9]))
    i_trues.append(float(line.split()[10]))
    w_trues.append(float(line.split()[11]))
    W_trues.append(float(line.split()[12]))
    a_recs.append(float(line.split()[13]))
    e_recs.append(float(line.split()[14]))
    q_recs.append(float(line.split()[15]))
    css.append(float(line.split()[16]))
    z_guesses.append(float(line.split()[17]))
    z_trues.append(float(line.split()[18]))
    
    dofs.append(2*int(line.split()[3][-2:])-6)
    
objs = np.array(objs)
arcs = np.array(arcs)
epochs = np.array(epochs)
obss = np.array(obss)
sigma_as = np.array(sigma_as)
sigma_es = np.array(sigma_es)
sigma_qs = np.array(sigma_qs)
a_trues = np.array(a_trues)
e_trues = np.array(e_trues)
q_trues = np.array(q_trues)
i_trues = np.array(i_trues)
w_trues = np.array(w_trues)
W_trues = np.array(W_trues)
a_recs = np.array(a_recs)
e_recs = np.array(e_recs)
q_recs = np.array(q_recs)
css = np.array(css)
z_guesses = np.array(z_guesses)
z_trues = np.array(z_trues)
dofs = np.array(dofs)

convergence_mask = [sigma_as > 0, a_recs < 100000]
convergence_mask = reduce(np.logical_and, convergence_mask)

plt.scatter(arcs, css / dofs)
plt.semilogy()
plt.xlabel('arc length [months]')
plt.ylabel(r'$\chi^2/\nu$')
plt.show()


sigmaz_zs = np.abs(z_guesses - z_trues) / z_trues

bins = np.logspace(np.log10(np.min(sigmaz_zs)), np.log10(np.max(sigmaz_zs)), 25)
#bins = np.linspace(np.min(sigmaz_zs), np.max(sigmaz_zs), 25)

plt.hist(sigmaz_zs[convergence_mask], histtype = 'step', color = 'black', label = 'converged (' + str(len(sigmaz_zs[convergence_mask])) + ')', bins = bins)#, density = True)
plt.hist(sigmaz_zs[~convergence_mask], histtype = 'step', color = 'red', label = 'failed (' + str(len(sigmaz_zs[~convergence_mask])) + ')', bins = bins)#, density = True)
plt.legend(loc = 'upper left')
plt.ylabel('#')
plt.xlabel(r'$\frac{\sigma_z}{z}$')
plt.semilogx()
plt.show()
exit(1)


# compare orbtial precision to eccentricity
ed={}
for p in range(len(e_trues[convergence_mask])):
    if str(e_trues[convergence_mask][p]) not in ed: ed[str(e_trues[convergence_mask][p])] = []
    ed[str(e_trues[convergence_mask][p])].append(sigma_as[convergence_mask][p])
means = []
medians = []
es = []
for key in ed.keys():
    means.append(np.mean(ed[key]))
    medians.append(np.median(ed[key]))
    es.append(float(key))
plt.title('Of those that converged...')
plt.scatter(es, means, label = 'mean')
plt.scatter(es, medians, label = 'median')
plt.legend()
plt.semilogy()
plt.ylabel(r'$\frac{\sigma_a}{a}$')
plt.xlabel('e')
plt.savefig('e_pass.png', dpi = 500)
plt.close('all')
# compare orbtial precision to semimajor axis
ad={}
for p in range(len(a_trues[convergence_mask])):
    if str(a_trues[convergence_mask][p]) not in ad: ad[str(a_trues[convergence_mask][p])] = []
    ad[str(a_trues[convergence_mask][p])].append(sigma_as[convergence_mask][p])
means = []
medians = []
es = []
for key in ad.keys():
    means.append(np.mean(ad[key]))
    medians.append(np.median(ad[key]))
    es.append(float(key))
plt.title('Of those that converged...')
plt.scatter(es, means, label = 'mean')
plt.scatter(es, medians, label = 'median')
plt.legend()
plt.semilogy()
plt.ylabel(r'$\frac{\sigma_a}{a}$')
plt.xlabel('a [AU]')
plt.savefig('a_pass.png', dpi = 500)
plt.close('all')
# compare orbtial precision to inclination
id={}
for p in range(len(i_trues[convergence_mask])):
    if str(i_trues[convergence_mask][p]) not in id: id[str(i_trues[convergence_mask][p])] = []
    id[str(i_trues[convergence_mask][p])].append(sigma_as[convergence_mask][p])
means = []
medians = []
es = []
for key in id.keys():
    means.append(np.mean(id[key]))
    medians.append(np.median(id[key]))
    es.append(float(key))
plt.title('Of those that converged...')
plt.scatter(es, means, label = 'mean')
plt.scatter(es, medians, label = 'median')
plt.legend()
plt.semilogy()
plt.ylabel(r'$\frac{\sigma_a}{a}$')
plt.xlabel('i [rad]')
plt.savefig('i_pass.png', dpi = 500)
plt.close('all')
plt.title('Of those that failed to converge...')
plt.hist(arcs[~convergence_mask], bins = 50, histtype = 'step')
plt.xlabel('arc length [months]')
plt.savefig('arc_fail.png', dpi = 500)
plt.close('all')
plt.title('Of those that failed to converge...')
plt.hist(e_trues[~convergence_mask], bins = 50, histtype = 'step')
plt.xlabel('e')
plt.savefig('e_fail.png', dpi = 500)
plt.close('all')
plt.title('Of those that failed to converge...')
plt.hist(a_trues[~convergence_mask], bins = 50, histtype = 'step')
plt.xlabel('a [AU]')
plt.savefig('a_fail.png', dpi = 500)
plt.close('all')
plt.title('Of those that failed to converge...')
plt.hist(i_trues[~convergence_mask], bins = 50, histtype = 'step')
plt.xlabel('i [rad]')
plt.savefig('i_fail.png', dpi = 500)
plt.close('all')
#plt.figure(figsize=(12, 5))
plt.hist(css[convergence_mask]/dofs[convergence_mask], histtype = 'step', bins = 500, density = True, color = 'darkblue')
plt.ylabel('PDF')
plt.xlabel(r'$\chi^2/\nu$')
plt.axvline(x=np.median(css[convergence_mask]/dofs[convergence_mask]), ls = '--', color = 'red', label = 'median', lw = 2)
plt.axvline(x=np.mean(css[convergence_mask]/dofs[convergence_mask]), ls = '--', color = 'black', label = 'mean', lw = 2)
plt.legend(loc = 'upper center', ncol = 2)
plt.xlim(0, 3)
plt.savefig('chi_squared_DOF.png', dpi = 500)
plt.close('all')

cs = []

pct_errs = 100. * np.abs((a_recs - a_trues) / np.array(a_trues))
pct_errs = np.array(pct_errs)

fig, ax = plt.subplots(figsize = (8, 4))
ax2 = ax.twinx()

for obj in objs:

    howmanyofthisobjecthasnotconverged = 0
    
    for o in objs[~convergence_mask]:
    
        if o == obj: howmanyofthisobjecthasnotconverged += 1
    
    ax.bar(obj, howmanyofthisobjecthasnotconverged, color = 'darkblue', zorder = 3)
    
ax.set_yticks([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19])#ticks=np.linspace(0, 18, 19), labels = np.linspace(0, 18, 19, dtype = 'int'))
new_ys = lambda old_ys: str(100 * old_ys / (190. / 10.)) + '%'
#plt.tick_params(labelright=True)
ax.set_xlabel('Objects (50)')
plt.title('19 arc lengths x 4 epochs x 50 objects = 3800 Total Simulations')
#ax.set_ylim(0, 19)
plt.xticks(ticks = plt.xticks()[0], labels = [''] * 10)
ax2.set_ylim(new_ys(0), new_ys(19))
ax.set_xticks(np.linspace(1, 10, 10))
ax.set_ylabel('Number of Failed Convergenes')
ax2.set_ylabel('Percentage of Object\'s Realizations')
ax.grid(axis = 'y', zorder = 0)
plt.savefig('failed_objects.png', dpi = 500)
plt.close('all')
plt.hist(pct_errs[convergence_mask], histtype = 'step',  bins = np.logspace(np.floor(np.log10(np.min(pct_errs[convergence_mask]))), np.ceil(np.log10(np.max(pct_errs[convergence_mask]))), 150), color = 'darkblue', lw = 2)
plt.semilogx()
plt.xlabel('Percent Error on Semimajor Axis Recovery')
plt.axvline(x = np.mean(pct_errs[convergence_mask]), ls = '--', alpha = 0.5, color = 'black', label = 'mean='  +str(round(np.mean(pct_errs[convergence_mask]), 4)) + '%')
plt.axvline(x = np.median(pct_errs[convergence_mask]), ls = '--', alpha = 0.5, color = 'red', label = 'median='  +str(round(np.median(pct_errs[convergence_mask]), 4)) + '%')
plt.legend()
plt.savefig('pct_err_on_a.png', dpi = 500)
plt.close('all')
arc10_mask = arcs == 1.0
arc15_mask = arcs == 1.5
arc20_mask = arcs == 2.0
arc25_mask = arcs == 2.5
arc30_mask = arcs == 3.0
arc35_mask = arcs == 3.5
arc40_mask = arcs == 4.0
arc45_mask = arcs == 4.5
arc50_mask = arcs == 5.0
arc55_mask = arcs == 5.5
arc60_mask = arcs == 6.0
arc65_mask = arcs == 6.5
arc70_mask = arcs == 7.0
arc75_mask = arcs == 7.5
arc80_mask = arcs == 8.0
arc85_mask = arcs == 8.5
arc90_mask = arcs == 9.0
arc95_mask = arcs == 9.5
arc100_mask = arcs == 10.0

labs = ['1mo', '1.5mo', '2mo', '2.5mo', '3mo', '3.5mo', '4mo', '4.5mo', '5mo', '5.5mo', '6mo', '6.5mo', '7mo', '7.5mo', '8mo', '8.5mo', '9mo', '9.5mo', '10mo']
l = 0
for mask in [arc10_mask, arc15_mask, arc20_mask, arc25_mask, arc30_mask, arc35_mask, arc40_mask, arc45_mask, arc50_mask, arc55_mask, arc60_mask, arc65_mask, arc70_mask, arc75_mask, arc80_mask, arc85_mask, arc90_mask, arc95_mask, arc100_mask]:
    #plt.hist(cs_tots[mask] / obss[mask], log = True, histtype = 'step', bins = np.logspace(10**np.min(cs_tots/obss), 10**np.max(cs_tots/obss)))
    plt.hist(100. * np.abs((a_recs[mask] - a_trues[mask]) / a_trues[mask]), histtype = 'step', log = True, bins = 100, label = labs[l])
    l += 1

plt.legend()
plt.close('all')
# how do our sigma-a/as go as a function of eccentricity
plt.scatter(e_trues, sigma_as, c = 19 * np.array(arcs) + np.array(obss))
plt.colorbar(label = 'arc length [mo] + # obs')
plt.semilogy()
plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
plt.xlabel('e')
plt.ylabel(r'$\frac{\sigma_a}{a}$')
plt.savefig('mysample_sigma_as_vs_e.png', dpi = 500)
plt.close('all')

# how do our sigma-a/as go as a function of arc length
plt.scatter(19 * np.array(arcs), sigma_as, c = np.array(obss))
plt.semilogy()
plt.colorbar(label = '# obs')
plt.xlabel('arc length [mo]')
plt.ylabel(r'$\frac{\sigma_a}{a}$')
plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
plt.savefig('mysample_50_object_sample.png', dpi = 500)
    
plt.close('all')

do_avg = False
do_median = True

if do_avg:

    avg_str = 'Average '
    
else: avg_str = ''

plt.figure(figsize = (12, 6))

for num_epochs in [3, 5, 10, 30]:

    if num_epochs == 3: color = 'blue'; start = 0; finish = int(len(np.array(epochs)[np.array(epochs) == 3]))
    elif num_epochs == 5: color = 'black'; start = int(len(np.array(epochs)[np.array(epochs) == 3])); finish = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5]))
    elif num_epochs == 10: color = 'orange'; start = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5])); finish = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5])) + int(len(np.array(epochs)[np.array(epochs) == 10]))
    elif num_epochs == 30: color = 'green'; start = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5])) + int(len(np.array(epochs)[np.array(epochs) == 10])); finish = None

    trimmed_trues = range(len(sigma_as))[start:finish:19]

    xs = []
    ys = []

    for j in trimmed_trues:

        xs.append(arcs[j:j+19])
        ys.append(sigma_as[j:j+19])
        
        if True:#not do_avg and not do_median:
        
            if j != trimmed_trues[-1]:

                #plt.scatter(arcs[j:j+19], sigma_as[j:j+19],color = color)
                plt.plot(arcs[j:j+19][convergence_mask[j:j+19] == True], sigma_as[j:j+19][convergence_mask[j:j+19] == True], color = color, alpha = 0.05)
            
            else:
        
                #plt.scatter(arcs[j:j+19], sigma_as[j:j+19],color = color)
                plt.plot(arcs[j:j+19][convergence_mask[j:j+19] == True], sigma_as[j:j+19][convergence_mask[j:j+19] == True], color = color, alpha = 0.05)# label = str(num_epochs) + ' obs', alpha = 0.1)
    
for num_epochs in [3, 5, 10, 30]:

    if num_epochs == 3: no = '7'
    elif num_epochs == 5: no = '10'
    elif num_epochs == 10: no = '18'
    elif num_epochs == 30: no = '48'

    if num_epochs == 3: color = 'blue'; start = 0; finish = int(len(np.array(epochs)[np.array(epochs) == 3]))
    elif num_epochs == 5: color = 'black'; start = int(len(np.array(epochs)[np.array(epochs) == 3])); finish = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5]))
    elif num_epochs == 10: color = 'orange'; start = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5])); finish = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5])) + int(len(np.array(epochs)[np.array(epochs) == 10]))
    elif num_epochs == 30: color = 'green'; start = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 5])) + int(len(np.array(epochs)[np.array(epochs) == 10])); finish = None

    trimmed_trues = range(len(sigma_as))[start:finish:19]

    xs = []
    ys = []

    for j in trimmed_trues:

        xs.append(arcs[j:j+19])#[convergence_mask[j:j+19] == True])
        ys.append(sigma_as[j:j+19])#[convergence_mask[j:j+19] == True])
    
    if do_avg and not do_median:
    
        #plt.scatter(np.mean(xs, axis = 0), np.mean(ys, axis = 0), color = color)
        plt.plot(np.mean(xs, axis = 0), np.mean(ys, axis = 0), color = color, label = str(num_epochs) + ' epochs (' + no + ' obs)', lw = 4)
        #plt.ylim(1e-3, 1e0)
        
    if do_median and not do_avg:
    
        #plt.scatter(np.median(xs, axis = 0), np.median(ys, axis = 0), color = color)
        plt.plot(np.median(xs, axis = 0), np.median(ys, axis = 0), color = color, label = str(num_epochs) + ' epochs (' + no + ' obs)', lw = 4)
        #plt.ylim(1e-3, 1e0)
        avg_str = 'Median '
    
plt.semilogy()
plt.title('50 OSSOS Objects (Astrometric Error ' + r'$\sim$' + '25mas)')
plt.xlabel('Arc Length [months]')
plt.ylabel(avg_str + r'$\frac{\sigma_a}{a}$')
plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
plt.xlim(0.5, 6)
plt.legend()
plt.savefig('ALL_sigma_a_versus_arc' + avg_str[:-1] + '.png', dpi = 500)
#plt.close('all')
# we can collect all the data from 237 OSSOS objects with MPC designations here
OSSOS_objects_data = ascii.read('../OSSOS_B.CDS')#[1::5] # just take every 5th object!
obsss = np.array(OSSOS_objects_data['Nobs'])
arcss = np.array(OSSOS_objects_data['time'])
sigma_ass = np.array(OSSOS_objects_data['e_a']) / np.array(OSSOS_objects_data['a'])
'''
plt.hist(sigma_ass, histtype = 'step', label = 'OSSOS', bins = np.logspace(-6, 1, 150), density = True, color = 'orange')
plt.hist(sigma_as[convergence_mask], histtype = 'step', label = 'JWST', bins = np.logspace(-6, 1, 150), density = True, color = 'darkblue')
plt.xlabel(r'$\frac{\sigma_a}{a}$')
plt.legend()
plt.semilogx()
plt.savefig('sigma_a_comp_to_OSSOS.png', dpi = 500)
exit(1)
'''
'''
obsss.sort()
arcss = np.array([x for _,x in sorted(zip(obsss, arcss))])
sigma_ass = np.array([x for _,x in sorted(zip(obsss, sigma_ass))])
'''

plt.scatter(12 * arcss, sigma_ass, c = obsss, label = 'OSSOS')

for i, txt in enumerate(obsss):
    plt.annotate(txt, (12 * arcss[i], sigma_ass[i]), color = 'white', fontsize = 4, ha = 'center', va = 'center')
#, s = 5)
'''
for i in range(len(arcss)):
    if i == 0: plt.scatter(12 * arcss, sigma_ass, c = obsss, label = 'OSSOS')
    else: plt.scatter(12 * arcss, sigma_ass, c = obsss)
    plt.text(12 * arcss[i], sigma_ass[i], str(obsss[i]), color = 'white', fontsize = 4, ha = 'center', va = 'center')
'''
plt.semilogy()
plt.colorbar(label = 'Number of Observations from OSSOS')
#plt.xlabel('arc length [mo]')
#plt.ylabel(r'$\frac{\sigma_a}{a}$')
#plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
plt.ylim(5e-6, 2)
plt.xlim(1, 300)
plt.axvline(x = 12, ls = '--', alpha = 0.5, c = 'C0', zorder = 0)
plt.axvline(x = 24, ls = '--', alpha = 0.5, c = 'C0', zorder = 0)
plt.axvline(x = 36, ls = '--', alpha = 0.5, c = 'C0', zorder = 0)
plt.axvline(x = 48, ls = '--', alpha = 0.5, c = 'C0', zorder = 0)
plt.axvline(x = 60, ls = '--', alpha = 0.5, c = 'C0', zorder = 0)
plt.axvline(x = 120, ls = '--', alpha = 0.5, c = 'C0', zorder = 0)
plt.text(12.2, 7.35e-6, '1 year', rotation = 270, alpha = 0.5, c = 'C0')
plt.text(24.39, 6e-6, '2 years', rotation = 270, alpha = 0.5, c = 'C0')
plt.text(36.52, 6e-6, '3 years', rotation = 270, alpha = 0.5, c = 'C0')
plt.text(48.75, 6e-6, '4 years', rotation = 270, alpha = 0.5, c = 'C0')
plt.text(60.9, 6e-6, '5 years', rotation = 270, alpha = 0.5, c = 'C0')
plt.text(121.75, 6e-6, '10 years', rotation = 270, alpha = 0.5, c = 'C0')
plt.legend()
plt.semilogx()
#plt.tight_layout()
plt.savefig('log_combined_object_sample' + avg_str[:-1] + '.png', dpi = 500)
plt.xlim(0, 60)
plt.savefig('log_combined_object_sample_zoomed' + avg_str[:-1] + '.png', dpi = 500)

plt.close('all')
