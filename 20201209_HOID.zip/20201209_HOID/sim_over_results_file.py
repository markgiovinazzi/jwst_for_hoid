import matplotlib.pyplot as plt
import numpy as np
from astropy.io import ascii

file_name = 'perihelion_data.txt'

f = open(file_name, 'r')

lines = f.readlines()

arcs, epochs, obss, sigma_as, sigma_es, sigma_qs, a_list, e_list, q_list, i_list, w_list, W_list, cs_binds, cs_gammas, cs_lss, cs_tots, a_recs, e_recs, q_recs = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []

for line in lines[1:]:

    arcs.append(float(line.split()[1][:-2]))
    epochs.append(int(line.split()[2][-2:]))
    obss.append(int(line.split()[3][-2:]))
    sigma_as.append(float(line.split()[4]))
    sigma_es.append(float(line.split()[5]))
    sigma_qs.append(float(line.split()[6]))
    a_list.append(float(line.split()[7]))
    e_list.append(float(line.split()[8]))
    q_list.append(float(line.split()[9]))
    i_list.append(float(line.split()[10]))
    w_list.append(float(line.split()[11]))
    W_list.append(float(line.split()[12]))
    cs_binds.append(float(line.split()[13]))
    cs_gammas.append(float(line.split()[14]))
    cs_lss.append(float(line.split()[15]))
    cs_tots.append(float(line.split()[16]))
    a_recs.append(float(line.split()[17]))
    e_recs.append(float(line.split()[18]))
    q_recs.append(float(line.split()[19]))
    
a_recs = np.array(a_recs)
e_recs = np.array(e_recs)
q_recs = np.array(q_recs)

a_list = np.array(a_list)
e_list = np.array(e_list)
q_list = np.array(q_list)

sigma_as = sigma_as * a_list / a_recs
sigma_es = sigma_es * e_list / e_recs
sigma_qs = sigma_qs * q_list / q_recs

arcs = np.array(arcs)
obss = np.array(obss)
cs_tots = np.array(cs_tots)

arc10_mask = arcs == 1.0
arc15_mask = arcs == 1.5
arc20_mask = arcs == 2.0
arc25_mask = arcs == 2.5
arc30_mask = arcs == 3.0
arc35_mask = arcs == 3.5
arc40_mask = arcs == 4.0
arc45_mask = arcs == 4.5
arc50_mask = arcs == 5.0
arc55_mask = arcs == 5.5
arc60_mask = arcs == 6.0
arc65_mask = arcs == 6.5
arc70_mask = arcs == 7.0
arc75_mask = arcs == 7.5
arc80_mask = arcs == 8.0
arc85_mask = arcs == 8.5
arc90_mask = arcs == 9.0
arc95_mask = arcs == 9.5
arc100_mask = arcs == 10.0

print(np.min(cs_tots / obss), np.max(cs_tots / obss))
plt.scatter(range(len(cs_lss / obss)), cs_lss / obss, c = obss)
plt.colorbar()
plt.semilogy()

for mask in [arc10_mask, arc15_mask, arc20_mask, arc25_mask, arc30_mask, arc35_mask, arc40_mask, arc45_mask, arc50_mask, arc55_mask, arc60_mask, arc65_mask, arc70_mask, arc75_mask, arc80_mask, arc85_mask, arc90_mask, arc95_mask, arc100_mask]:
    plt.hist(cs_tots[mask] / obss[mask], log = True, histtype = 'step', bins = np.logspace(10**np.min(cs_tots/obss), 10**np.max(cs_tots/obss)))
plt.semilogx()
plt.show()

# how do our sigma-a/as go as a function of eccentricity
plt.scatter(e_list, sigma_as, c = 19 * np.array(arcs) + np.array(obss))
plt.colorbar(label = 'arc length [mo] + # obs')
plt.semilogy()
plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
plt.xlabel('e')
plt.ylabel(r'$\frac{\sigma_a}{a}$')
plt.savefig('mysample_sigma_as_vs_e.png', dpi = 500)
plt.close('all')

# how do our sigma-a/as go as a function of arc length
plt.scatter(19 * np.array(arcs), sigma_as, c = np.array(obss))
plt.semilogy()
plt.colorbar(label = '# obs')
plt.xlabel('arc length [mo]')
plt.ylabel(r'$\frac{\sigma_a}{a}$')
plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
plt.savefig('mysample_50_object_sample.png', dpi = 500)
    
plt.close('all')

do_avg = False
do_median = True

if do_avg:

    avg_str = 'Average '
    
else: avg_str = ''

plt.figure(figsize = (12, 6))

for num_epochs in [3, 10, 30]:

    if num_epochs == 3: color = 'blue'; start = 0; finish = int(len(np.array(epochs)[np.array(epochs) == 3]))
    elif num_epochs == 10: color = 'orange'; start = int(len(np.array(epochs)[np.array(epochs) == 3])); finish = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 10]))
    elif num_epochs == 30: color = 'green'; start = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 10])); finish = None

    trimmed_list = range(len(sigma_as))[start:finish:19]

    xs = []
    ys = []

    for j in trimmed_list:

        xs.append(arcs[j:j+19])
        ys.append(sigma_as[j:j+19])
        
        if True:#not do_avg and not do_median:
        
            if j != trimmed_list[-1]:

                #plt.scatter(arcs[j:j+19], sigma_as[j:j+19],color = color)
                plt.plot(arcs[j:j+19], sigma_as[j:j+19],color = color, alpha = 0.05)
            
            else:
        
                #plt.scatter(arcs[j:j+19], sigma_as[j:j+19],color = color)
                plt.plot(arcs[j:j+19], sigma_as[j:j+19],color = color, alpha = 0.05)# label = str(num_epochs) + ' obs', alpha = 0.1)
    
for num_epochs in [3, 10, 30]:

    if num_epochs == 3: no = '7'
    elif num_epochs == 10: no = '18'
    elif num_epochs == 30: no = '48'

    if num_epochs == 3: color = 'blue'; start = 0; finish = int(len(np.array(epochs)[np.array(epochs) == 3]))
    elif num_epochs == 10: color = 'orange'; start = int(len(np.array(epochs)[np.array(epochs) ==3])); finish = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 10]))
    elif num_epochs == 30: color = 'green'; start = int(len(np.array(epochs)[np.array(epochs) == 3])) + int(len(np.array(epochs)[np.array(epochs) == 10])); finish = None

    trimmed_list = range(len(sigma_as))[start:finish:19]

    xs = []
    ys = []

    for j in trimmed_list:

        xs.append(arcs[j:j+19])
        ys.append(sigma_as[j:j+19])
    
    if do_avg and not do_median:
    
        #plt.scatter(np.mean(xs, axis = 0), np.mean(ys, axis = 0), color = color)
        plt.plot(np.mean(xs, axis = 0), np.mean(ys, axis = 0), color = color, label = str(num_epochs) + ' epochs (' + no + ' obs)', lw = 4)
        #plt.ylim(1e-3, 1e0)
        
    if do_median and not do_avg:
    
        #plt.scatter(np.median(xs, axis = 0), np.median(ys, axis = 0), color = color)
        plt.plot(np.median(xs, axis = 0), np.median(ys, axis = 0), color = color, label = str(num_epochs) + ' epochs (' + no + ' obs)', lw = 4)
        #plt.ylim(1e-3, 1e0)
        avg_str = 'Median '
    
plt.semilogy()
plt.title('50 OSSOS Objects (Astrometric Error ' + r'$\sim$' + '25mas)')
plt.xlabel('Arc Length [months]')
plt.ylabel(avg_str + r'$\frac{\sigma_a}{a}$')
plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
plt.xlim(0.5, 6)
plt.legend()
plt.savefig('ALL_sigma_a_versus_arc' + avg_str[:-1] + '.png', dpi = 500)

# we can collect all the data from 237 OSSOS objects with MPC designations here
OSSOS_objects_data = ascii.read('../OSSOS_B.CDS')#[1::5] # just take every 5th object!

obsss = np.array(OSSOS_objects_data['Nobs'])
arcss = np.array(OSSOS_objects_data['time'])
sigma_ass = np.array(OSSOS_objects_data['e_a']) / np.array(OSSOS_objects_data['a'])

plt.scatter(19 * arcss, sigma_ass, c = obsss, label = 'OSSOS')
plt.semilogy()
plt.colorbar(label = '# obs')
#plt.xlabel('arc length [mo]')
#plt.ylabel(r'$\frac{\sigma_a}{a}$')
#plt.ylim(0.9 * np.min(sigma_as), 1.1 * np.max(sigma_as))
#plt.ylim(ymin=5e-6)
plt.xlim(1., 1.1 * np.max(arcss))
plt.legend()
plt.semilogx()
plt.xlim(0, 300)
plt.savefig('log_combined_object_sample' + avg_str[:-1] + '.png', dpi = 500)
plt.xlim(0, 60)
plt.savefig('log_combined_object_sample_zoomed' + avg_str[:-1] + '.png', dpi = 500)

plt.close('all')
