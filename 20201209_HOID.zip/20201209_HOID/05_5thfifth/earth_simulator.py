import numpy as np

def rotate_earth(t, t0, phi0):

    # give actual time of day in seconds
    t_day = 23 * 3600 + 56 * 60 + 4.0916

    phi = 2 * np.pi * (t - t0) / t_day + phi0
    
    return phi
    
def axial_tilt(t, t0, theta0):

    T_trop = 365.242190 * 24 * 3600

    theta = 2 * np.pi * (t - t0) / T_trop + theta0

    return theta
