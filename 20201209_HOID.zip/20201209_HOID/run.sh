#!/bin/bash

declare -a Nobs=("05")
declare -a whichbatch=("1st" "2nd" "3rd" "4th" "5th")

for N in "${Nobs[@]}"; do
    for which in "${whichbatch[@]}"; do
        cd $N"_"$which"fifth"
        python3 "analysis.py" &
        cd ".."
    done
done

